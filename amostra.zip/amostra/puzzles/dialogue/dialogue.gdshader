shader_type canvas_item;
uniform vec4 colorGreen = vec4(0.6, 0.89803921568627450980392156862745, 0.3137254901960784313725490196078, 1.0);
uniform float intensity = 0.1;
void vertex() {
	// Called for every vertex the material is visible on.
}

void fragment() {
	//vec4 inputColor = texture(TEXTURE, vec2(UV.x+sin(TIME*2.0),UV.y));
	//if (COLOR == colorGreen){
		//if (inputColor == colorGreen){COLOR = inputColor;}
		//else{COLOR=vec4(0.0,0.0,0.0,1.0);}}
	if (COLOR == colorGreen){

		if (UV.x+cos(TIME)>0.5){
			COLOR = vec4(0.0,0.0,0.0,1.0);
			
		}
	}
	// Called for every pixel the material is visible on.
}

//void light() {
//	// Called for every pixel for every light affecting the CanvasItem.
//	// Uncomment to replace the default light processing function with this one.
//}
