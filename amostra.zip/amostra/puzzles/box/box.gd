extends CharacterBody2D

@export var weight = 300
const SPEED = 300.0
@onready var area_2d: Area2D = $Area2D
var charIn = false
var keyIn = false
var beingPushed = false
@onready var sprite_2d: Sprite2D = $Sprite2D

var fire = preload("res://fireDispenser/fire_particle.tscn")

@onready var state_machine: StateMachine = $StateMachine

var tween

func changeSpr(img):
	sprite_2d.texture = img

func burn():
	state_machine.change_state("burn")
	pass


func setMonitoring(value:bool):
	area_2d.monitoring = value


func _physics_process(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0, 3)
	# Add the gravity.
	if not is_on_floor():
		area_2d.monitoring=true
		velocity += get_gravity() * delta
	move_and_slide()
	

func transparent():
	set_collision_layer_value(2, true)
	set_collision_layer_value(1, false)
	set_collision_mask_value(2, true)
	set_collision_mask_value(1, false)
	set_collision_layer_value(9, true)
	set_collision_mask_value(9, true)
	set_collision_layer_value(12, false)

	tween = get_tree().create_tween()
	tween.tween_property(sprite_2d, "modulate:a", 0.4, 0.2)
	pass
func pushed():
	set_collision_layer_value(2, false)
	set_collision_layer_value(1, false)
	set_collision_mask_value(2, false)
	set_collision_mask_value(1, false)
	set_collision_layer_value(9, false)
	set_collision_mask_value(9, false)
	set_collision_layer_value(12, true)
	tween = get_tree().create_tween()
	tween.tween_property(sprite_2d, "modulate:a", 1, 0.2)
func solid():
	set_collision_layer_value(2, false)
	set_collision_layer_value(1, true)
	set_collision_mask_value(2, false)
	set_collision_mask_value(1, true)
	set_collision_layer_value(9, true)
	set_collision_mask_value(9, true)
	set_collision_layer_value(12, false)
	tween = get_tree().create_tween()
	tween.tween_property(sprite_2d, "modulate:a", 1, 0.2)
func setBeingPushed(value):
	beingPushed = value
	if beingPushed:
		pushed()
func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("char"):
		charIn=true

	elif body.is_in_group("key"):
		keyIn=true

	elif body.is_in_group("boxes"):
		if body.beingPushed:
			keyIn = true
	pass # Replace with function body.


func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.is_in_group("char"):
		charIn=false
	
	elif body.is_in_group("key"):
		keyIn=false
		
	elif body.is_in_group("boxes"):
		if body.beingPushed:
			keyIn = false

		
