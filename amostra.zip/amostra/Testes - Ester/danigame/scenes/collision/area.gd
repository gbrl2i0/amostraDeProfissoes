extends Area2D

@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D

func set_area(radius:int = 0, translate_x:int = 0, translate_y = 0):
	var real_parent = Danigame.get_display_parent(self)
	if not real_parent:
		return
	
	var width = real_parent.width
	
	var _radius = width if radius == 0 else radius
	
	var _shape:CircleShape2D = CircleShape2D.new()
	_shape.radius = _radius
	collision_shape_2d.shape = _shape
		
	position.x += translate_x
	position.y += translate_y
