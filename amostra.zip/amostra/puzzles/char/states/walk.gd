extends State
@onready var footsteps: AudioStreamPlayer2D = $"../../footsteps"

func enter():
	#little animation when entering
	father._tween("scale",Vector2(3,0.00001),0.1)
	father._tween("scale",Vector2(1,1),0.2)
	if father.box_check:
		father.box_check.monitoring = false
		father.box_check.monitoring = true
	pass

func update(_delta):
	if father.getGround():
		father.inBelt = true if father.getGround().is_in_group("belt") else false
	
	#in case we just landed, rotation = 0, reffer to airborne state
	father.animated_sprite_2d.rotation = 0
	#what this state does?
	father._handleMovement(1,0.12)
	father._handleJump()
		
	father._handleSpriteDir()
	father._manejarAclamacion()
	if Input.is_action_just_pressed("shift"):
		father._handleDialogue()
	if father.velocity.x!=0:
		father._play("walk")
	else:
		father._play("idle")
	#change state when of ground
	if not father.is_on_floor():
		statemachine.change_state("airborne")
	father._handleGravity(_delta)
	
	if Input.is_action_just_pressed("shift") and father.selectedPOCandidates.size()>0:
		statemachine.change_state("selecting")
		pass
	#father._handleGravity(_delta)
	pass

func exit():
	pass
