extends DisplayObject

class_name Sprite

const sprite_scene = preload("res://danigame/scenes/sprite/sprite.tscn")

var sprite: Sprite2D
var path_sprite: String
var h_frames:int = 1
var v_frames:int = 1

@onready var sprite_container: Node2D = $SpriteContainer
@onready var area: Area2D = $Area
@onready var body: CollisionShape2D = $StaticBody2D/Body

var frame := 0:
	set(value):
		if sprite:
			frame = value
			sprite.frame = frame
	get:
		return frame

var pixelart := true:
	set(value):
		pixelart = value
		if sprite:
			sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if value == true else CanvasItem.TEXTURE_FILTER_LINEAR
	get:
		return pixelart


static func create(path:String, horiz_frames:int = 1, vert_frames:int = 1):
	var s:Sprite = sprite_scene.instantiate() as Sprite
	s.init(path, horiz_frames, vert_frames)
	
	return s


func init(path: String, horiz_frames:int = 1, vert_frames:int = 1):
	path_sprite = path
	h_frames = horiz_frames
	v_frames = vert_frames
	


func _ready():
	var image = load(path_sprite)
	
	sprite = Sprite2D.new()
	sprite.texture = image
	sprite.hframes = h_frames
	sprite.vframes = v_frames
	pixelart = true
	sprite_container.add_child(sprite)
	
	width = sprite.texture.get_width() if h_frames == 0 else sprite.texture.get_width() / h_frames
	height = sprite.texture.get_height() if v_frames == 0 else sprite.texture.get_height() / v_frames
	set_body_circle()
	set_area()
	


#****************** COLLISION *******************
func set_body_circle(radius:int = 0, translate_x:int = 0, translate_y = 0):
	body.set_body_circle(radius, translate_x, translate_y)
	
	
func set_body_rect(w:int = 0, h:int = 0, translate_x:int = 0, translate_y = 0):
	body.set_body_rect(w, h, translate_x, translate_y)


func set_body_enabled(status:bool):
	body.set_enabled(status)


func set_area(radius:int = 0, translate_x:int = 0, translate_y = 0):
	area.set_area(radius, translate_x, translate_y)
