extends DisplayObject

class_name Polygon

var points: PackedVector2Array
var _color: Color
var rect: Rect2

func _init(ppoints:PackedVector2Array, pcolor:Color):
	points = ppoints
	_color = pcolor
	
	var min = Vector2(INF, INF)
	var max = Vector2(-INF, -INF)
	for p in points:
		if p.x < min.x:
			min.x = p.x
		if p.x > max.x:
			max.x = p.x
		
		if p.y < min.y:
			min.y = p.y
		if p.y > max.y:
			max.y = p.y
	
	rect = Rect2(min, max)

func get_width():
	return rect.size.x
	
func get_height():
	return rect.size.y


func _draw():
	draw_colored_polygon (points, _color)
