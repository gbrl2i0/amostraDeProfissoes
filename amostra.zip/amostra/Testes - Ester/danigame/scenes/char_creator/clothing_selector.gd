extends Control
var clothes={"bodies":"res://imagens/avatar/character/bodies.png",
"eyes":"res://imagens/avatar/character/eyes.png",
"hair":"res://imagens/avatar/character/hairstyles.png",
"accessories":"res://imagens/avatar/character/accessories.png",
"outfits":"res://imagens/avatar/character/outfits.png"}
var button_scene= preload("res://danigame/scenes/char_creator/button.tscn")
var grid
var scroll
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	grid=get_node("GridContainer")
	scroll=get_node("VScrollBar")
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	grid.position=Vector2(40,138)-Vector2(0,scroll.value)
	pass
func generate(clothing_type:String="",c=clothes):
	grid=get_node("GridContainer")
	scroll=get_node("VScrollBar")
	var dummies=$GridContainer/dummies
	var texture:Texture2D = load(c[clothing_type]) as Texture2D
	var rows=(texture.get_height()/32)-1
	var row=0
	while row<=rows:
		var buttons_instance=button_scene.instantiate()
		grid.add_child(buttons_instance)
		buttons_instance.row=row
		var dummy=NPC.create_single(clothing_type,row,true)
		buttons_instance.add_child(dummy)
		buttons_instance.pressed.connect(_on_button_pressed)
		dummy.z_index=-1
		dummy.z_as_relative=false
		buttons_instance.z_index=-2
		dummy.position+=Vector2(20,36)
		row+=1
	scroll.max_value=((grid.get_children().size())/40)*300
		
	pass
func _on_button_pressed():
	pass
