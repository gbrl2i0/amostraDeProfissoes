extends CharacterBody2D


const SPEED = 300.0
@onready var sprite_2d: Sprite2D = $Sprite2D

var tween

func changeSpr(img):
	sprite_2d.texture = img

func _physics_process(delta: float) -> void:
		
	velocity.x = move_toward(velocity.x, 0, 2.5)
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

		

	move_and_slide()


		
