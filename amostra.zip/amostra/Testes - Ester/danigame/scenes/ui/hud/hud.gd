extends CanvasLayer

class_name UIHUD

@export var heart_scene:PackedScene

@onready var heart_container: HBoxContainer = %HeartContainer
@onready var label_coin: Label = %LabelCoin
@onready var interact_container: MarginContainer = $Control/MarginContainer/VBoxContainer/InteractContainer
@onready var label_interact: Label = %LabelInteract

var hearts_list:Array = []

var coins := 0:
	set(value): 
		coins = value
		label_coin.text = "%05d" % value
	get: 
		return coins


var hearts := 0:
	set(value): 
		hearts = value
		for i in hearts_list.size():
			hearts_list[i].set_heart(1 if i < value else 0)
	get: 
		return hearts


var total_hearts := 0:
	set(value):
		clear_hearts()
		for i in range(value):
			var heart = heart_scene.instantiate()
			heart_container.add_child(heart)
			hearts_list.append(heart)
		hearts = value
	get:
		return hearts_list.size()


var interact := '':
	set(value):
		if value == interact:
			return
		interact = value
		label_interact.text = interact
		label_interact.visible = false if interact.is_empty() else true
	get:
		return interact


func _ready() -> void:
	clear_hearts()
	label_interact.visible = false


func clear_hearts():
	hearts_list.clear()
	for heart in heart_container.get_children():
		heart.queue_free()
