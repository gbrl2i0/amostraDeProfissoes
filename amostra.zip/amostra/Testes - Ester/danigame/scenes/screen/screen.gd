extends CanvasLayer

signal closed

@onready var label = %Label
@onready var button:Button = %Button

var text: String = ""

func _ready():
	button.grab_focus()
	pass


func set_title(title:String):
	label.text = title



func _on_button_pressed():
	closed.emit()
	queue_free()
