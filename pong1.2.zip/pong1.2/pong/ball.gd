extends CharacterBody2D
var speed = Vector2(30,14)
var dirx = -1
var diry = 0
var bodya=null
var bodymov=""
@export var bullshit = false
var ball_scene=preload("res://ball.tscn")
var rebate = false
var timer = 0

func _process(delta: float) -> void:

	if not rebate:
		velocity = speed*Vector2(dirx,diry)
	else:
		velocity=Vector2(0,0)
		if bodya and bodya.name!="limites":
			bodya.velocity=Vector2(0,0)
			if Input.is_action_pressed("p"+str(bodya.num)):
				timer=0
	timer-=delta
	if timer<=0 and rebate:
		rebatida(bodya)
	move_and_slide()
	


func _on_area_2d_body_entered(body: Node2D) -> void:
	bodya=body
	if bodya.name.contains("bar"):
		body.speed=0
		timer = 0.05+(speed.x-29)/50000
	else:
		timer=0.001
	rebate=true

func rebatida(body):
	if body.name.contains("bar"):

			
		dirx=-dirx
		diry = body.dir
		body.speed=35
		if bullshit:
			var ball_instance = ball_scene.instantiate()
			add_child(ball_instance)
			ball_instance.diry=-diry
		speed.x+=10
		
	elif body.name=="limites":
		diry=-diry
	rebate=false
	
