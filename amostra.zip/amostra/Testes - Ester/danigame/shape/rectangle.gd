extends DisplayObject

class_name Rectangle

var rect: Rect2
var _color: Color
var filled: bool
var stroke: float

func _init(px:float, py:float, pw:float, ph:float, pcolor:Color, pfilled:bool, pstroke:float):
	rect = Rect2(0, 0, pw, ph)
	_color = pcolor
	filled = pfilled
	stroke = pstroke
	x = px
	y = py

func get_width():
	return rect.size.x
	
func get_height():
	return rect.size.y

func _draw():
	draw_rect(rect, _color, filled, stroke)
