extends Button
var row=0
signal pressed_()
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_pressed():
	var root=get_parent().get_parent().get_parent().get_parent()
	root.clothing[root.selecting] = row
	root.show_character(root.clothing)
	return row
