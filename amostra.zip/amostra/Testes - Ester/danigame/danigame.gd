extends Node

class_name Danigame

var prompt_scene = preload("res://danigame/scenes/prompt/prompt.tscn")
var screen_scene = preload("res://danigame/scenes/screen/screen.tscn")
var hud_scene = preload("res://danigame/scenes/ui/hud/hud.tscn")
var inventory_scene = preload("res://danigame/scenes/ui/inventory/inventory.tscn")
var dialog_scene = preload("res://danigame/scenes/ui/dialog/dialog.tscn")
#var player_scene = preload("res://danigame/scenes/player/player.tscn")

var Camera:Camera2D
var HUD:UIHUD
var Inventory:UIInventory
var Dialog:UIDialog

func _init():
	if not Camera:
		Camera = Camera2D.new()
		add_child(Camera)
		Camera.zoom = Vector2(2.2, 2.2)
		Camera.position_smoothing_enabled = true
		Camera.position_smoothing_speed = 7.5
	
	if not HUD:
		HUD = hud_scene.instantiate()
		add_child(HUD)
	
	if not Inventory:
		Inventory = inventory_scene.instantiate()
		add_child(Inventory)
		
	if not Dialog:
		Dialog = dialog_scene.instantiate()
		add_child(Dialog)


func input(msg:String):
	var prompt_instance = prompt_scene.instantiate()
	add_child(prompt_instance)
	prompt_instance.set_title(msg)
	
	var prompt = await prompt_instance.prompted
	return prompt

func show(msg:String):
	var screen_instance = screen_scene.instantiate()
	add_child(screen_instance)
	screen_instance.set_title(msg)
	
	await screen_instance.closed

#func create_player():
	#var player_instance = player_scene.instantiate()
	#return player_instance

#func window_resolution(w:int, h:int):
	#get_window().content_scale_size = Vector2i(w, h)
	#
#func window_size(w:int, h:int):
	#get_window().size = Vector2i(w, h)
	#get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT

static func get_display_parent(obj:Node2D):
	if "width" in obj:
		return obj
	elif "width" in obj.get_parent():
		return obj.get_parent()
	elif "width" in obj.get_parent().get_parent():
		return obj.get_parent().get_parent()
	else:
		return null
