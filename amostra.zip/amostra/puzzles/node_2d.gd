extends Node2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@export var playAnim = false
@onready var animation_player: AnimationPlayer = $AnimationPlayer
@onready var explosion: AnimatedSprite2D = $explosion
@export var open = false
var rand = randi_range(1,1000)
@export var nextScene:String
var preloaded
# Called when the node enters the scene tree for the first time.
func _ready() -> void:

	playAnim = false
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if playAnim:
		if rand == 1:
			animated_sprite_2d.play("explode")
			explosion.play("default")
		else:
			animated_sprite_2d.play("open")
		playAnim = false
	pass


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("key"):
		body.remove_from_group("boxes")
		body.visible = false
		body.set_collision_mask_value(4, false)
		if rand == 1:
			animation_player.play("explode")
		else:
			animation_player.play("open")
	pass # Replace with function body.


func _on_char_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("char"):
		print("A")
		if open:
			get_tree().change_scene_to_file(nextScene)
