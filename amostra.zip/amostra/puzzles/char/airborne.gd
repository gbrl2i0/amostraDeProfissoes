extends State
func enter():
	father._apagarAclamacion()
	
	print(father.velocity.x)
	#pass

func update(_delta):
	#father._handleMovement(0.02,0.04,1)
	#father._handleMovement(1,0.04,0)
	if !father.inBelt:
		father._handleMovement()
		father._handleSpriteDir()
	else:
		father._handleMovement(1*_delta,0.001,1)
		
	if father.velocity.y>0:
		father._handleJump()
	
	father._play("idle")
	father._handleGravity(_delta)
	if father.velocity.y >= -50:
		father._tween("scale",Vector2(1.1,0.9),0.1)
	if father.is_on_floor():
		statemachine.change_state("walk")

func exit():
	pass
