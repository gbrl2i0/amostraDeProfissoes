extends CharacterBody2D
class_name pickableObject

const SPEED = 300.0
@onready var sprite_2d: Sprite2D = $Sprite2D
@export var sprite: String
@export var weight = 300
var tween
func _ready() -> void:

	var spr = load(sprite)
	sprite_2d.texture = spr




func changeSpr(img):
	sprite_2d.texture = img

func _physics_process(delta: float) -> void:
		
	velocity.x = move_toward(velocity.x, 0, 2.5)
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

		

	move_and_slide()


		
