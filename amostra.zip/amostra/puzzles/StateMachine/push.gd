extends State
#var jumpSquat = 0
#var startJump = false
#var timerJump = 0

var throwBuffer = false
func enter():
	father.state_machine_push.change_state("walk")
	father._tween("scale",Vector2(1,2),0.1)
	father._tween("scale",Vector2(1,1),0.2)
	father.box_check.monitoring = false
	father.selectedPOCandidates = []
	father._apagarAclamacion()
	
	pass


func update(_delta):
	pass
	##if not startJump:
	#father.animated_sprite_2d.rotation = 0
	#if father.is_on_floor():
		#father._handleMovement(0.8)
		#father._handleSpriteDir()
		##if Input.is_action_just_pressed("space") and father.is_on_floor():
			##startJump = true
			##jumpSquat = (father.selectedPO.weight/1200.0)
			##father._tween("scale",Vector2(1.1,0.9),jumpSquat)
			##timerJump = jumpSquat
			#
	#else:
		#if Input.is_action_just_pressed("shift"):
			#throwBuffer = true
		##timerJump-=_delta
		#if father.is_on_floor():
			#father._handleMovement(0)
			#father._handleSpriteDir()
		##if timerJump <= 0:
			##father._handleJumpWeighted(1,father.selectedPO.weight)
			##startJump = false
	#if !father.is_on_floor():
		#if !father.inBelt:
			#father._handleMovement(0.02,0.04,1)
		#else:
			#father._handleMovement(0.02,0.01,1)
	#if !father._handlePush():
		#father.drop()
		#statemachine.change_state("walk")
#
	#if father.velocity.x!=0:
		#father._play("walkPush")
	#else:
		#father._play("idlePush")
#
	#father._handleGravity(_delta)
	#if not startJump:
		#if Input.is_action_just_pressed("s"):
			#if father.drop():
				#statemachine.change_state("walk")
		#if Input.is_action_just_pressed("shift") or throwBuffer:
			#throwBuffer = false
			#if father._launch():
				#statemachine.change_state("walk")
	#pass

func exit():
	father.state_machine_push.change_state("inactive")
	pass
