extends Node2D
@onready var sprite_2d: Sprite2D = $Sprite2D
var aliveTime = randf_range(4,6)
var aliveTimeStart
var speed = Vector2(0,1)
var yMult = 1
var colors = [
	Color(0,0,0,1), #red
	Color(0,0,0,1), #red
	Color(0,0,0,1), #red
	Color(0,0,0,1), #red
	Color(0,0,0,1), #red
	Color(0,0,0,1), #red
	Color(0.2,0.2,0.2,1), #red
	Color(0.2,0.2,0.2,1), #red
	Color(0.2,0.2,0.2,1), #red
	Color(0.2,0.2,0.3,1), #red
	Color(0.2,0.2,0.3,1), #red
	Color(0.2,0.2,0.3,1), #red

]

var sizes = [
	Vector2(1.7,1.7),
	Vector2(1.6,1.6),
	Vector2(1.5,1.5),
	Vector2(1.4,1.4),
	Vector2(1.3,1.3),
]
# Called when the node enters the scene tree for the first time.
func modulateSpr(color:Color):
	sprite_2d.self_modulate = color

func _ready() -> void:
	aliveTimeStart=aliveTime
	sprite_2d.self_modulate = colors[randi_range(0,colors.size()-1)]
	sprite_2d.scale = sizes[randi_range(0, sizes.size()-1)]
	speed = Vector2(randf_range(0,0),randf_range(3.4,4.0)*yMult)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	aliveTime -= delta
	modulate.a = aliveTime/aliveTimeStart
	position.y+=speed.y
	speed.x-=delta/aliveTimeStart
	speed.y-=delta/aliveTimeStart
	
	if aliveTime<=0:
		queue_free()
	pass
