extends Node

class_name NPC

var a :Dictionary={"text"=""}
var inter

static func create_mixed(texture_path:String = "",dummie:bool=false):
	return create(DefaultPlayerAnimations.create_mixed(texture_path),dummie)

static func create_single(what,row,dummie:bool=false):
	return create(DefaultPlayerAnimations.create_single(what,row),dummie)

static func create_all(rows:Array=[-1,-1,-1,-1,-1,-1],dummie:bool=false):
	return create(DefaultPlayerAnimations.create_all(rows),dummie)
	
static func create(sprite_anim,dummie):
	var s=[]
	if sprite_anim is Array:
		s=sprite_anim
	else:
		s.append(sprite_anim)
	var character:Character = Character.create(s,true)
	character.is_default = true
	character.group = "npc"
	return character
	
