#	##       ##        ##          ######
#	####     ##       ####        ##    ##
#	## ##    ##      ##  ##      ##      ##
#	##  ##   ##     ##    ##     ##      ##
#	##   ##  ##    ##########    ##      ##
#	##    ## ##   ##        ##    ##    ##
#	##     ####  ##          ##    ######

#	##       ##  ##########  ##      ##        ##
#	####   ####  ##           ##    ##        ####
#	## ## ## ##  ##            ##  ##        ##  ##
#	##  ###  ##  ######         ####        ##    ##
#	##       ##  ##            ##  ##      ##########
#	##       ##  ##           ##    ##    ##        ##
#	##       ##  ##########  ##      ##  ##          ##



















extends Marker2D

class_name Marker

@export_enum("item", "npc", "pokemon") var tipo: String
@export var nome: String
@export_enum("down", "up", "left", "right") var direcao: String

func _ready() -> void:
	pass
