extends Label
class_name Text
var textSize=0.0
@export var textDuration=0.0
@export var wing = false
@export var color = Vector3(255,255,255)
var textContent = ""
var textShown = ""
var elapsedTime = 0
var dict = {"color":{"start":"%C","end":"%C"},
"shake":{"start":"%S","end":"%S"},
}
var specials=0
@export var shake=false

var checkSpecials=false
var lineChar = 0
var colChar = 0
var sceneSpecialChar=preload("res://Text/custom_letter.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	add_theme_color_override("font_color", Color(color.x/255, color.y/255, color.z/255, 1))
	textSize = text.length()
	textContent = text
	text=""
	pass # Replace with function body.
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _endText():
	textShown = textContent
	text = textShown
func _isRunning():
	return (textShown != textContent)
func _process(delta: float) -> void:
	
		
	var timeBetweenLetters = (textDuration/textContent.length())
	var font = preload("res://font/pixelated-wingdings.otf")
	if wing:
		add_theme_font_override("font", font)
	elapsedTime+=delta
	if elapsedTime >= timeBetweenLetters and textShown.length()+specials!=textContent.length():
			
		if shake:
			var instance = sceneSpecialChar.instantiate()
			instance.shake=true
			instance.wing=wing
			instance.color=color
			if wing:
				instance.posI=Vector2(get_children().size()*32,0)
			else:
				instance.posI=Vector2(lineChar*20, colChar*32)
				lineChar+=1
				if lineChar%57 == 0:
					lineChar = 0
					colChar+=1
			
			instance.text=textContent[textShown.length()+specials]
			
			
			add_child(instance)
			specials+=1
			pass
		elif !checkSpecials:
			textShown+=textContent[textShown.length()+specials]
		text = textShown
		elapsedTime=0
	pass
func clear():
	text = ""
	for a in get_children():
		a.queue_free()
