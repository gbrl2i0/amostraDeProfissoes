extends Node
class_name DefaultPlayerAnimations

static var paths=["res://imagens/avatar/character/bodies.png","res://imagens/avatar/character/eyes.png","res://imagens/avatar/character/hairstyles.png","res://imagens/avatar/character/accessories.png","res://imagens/avatar/character/outfits.png","res://imagens/avatar/character/accessories.png"]
static func create_all(row:Array=[-1,-1,-1,-1,-1,-1]):
	print(row)
	var s
	var ts=[]
	for path in paths:
		var texture:Texture2D = load(path) as Texture2D
		var pos=paths.find(path)
		if path == "res://imagens/avatar/character/accessories.png" and ts.size()>4:
			pos=5
		if row[pos]<=-1:
			row[pos] = randi_range(0, (texture.get_height()/32)-1)
		var tex:AtlasTexture = AtlasTexture.new()
		tex.atlas = texture
		tex.region = Rect2(0, row[pos]*32, texture.get_width(), 32)
		s = SpriteAnim.create_with_texture(tex, 240, 1)
		s.position.y+=-15
		s=generate_anims(s)
		s.play('idle_down')
		ts.append(s)
	return ts

static func create_single(what:String,row:int):
	var paths_={"bodies":"res://imagens/avatar/character/bodies.png",
	"eyes":"res://imagens/avatar/character/eyes.png",
	"hair":"res://imagens/avatar/character/hairstyles.png",
	"accessories":"res://imagens/avatar/character/accessories.png",
	"outfits":"res://imagens/avatar/character/outfits.png"}
	var s
	var texture:Texture2D = load(paths_[what]) as Texture2D
	var tex:AtlasTexture = AtlasTexture.new()
	tex.atlas = texture
	tex.region = Rect2(0, row*32, texture.get_width(), 32)
	s = SpriteAnim.create_with_texture(tex, 240, 1)
	s=generate_anims(s)
	s.play('idle_down')
	return s

static func create_mixed(path):
	var s
	var texture:Texture2D = load(path) as Texture2D
	var pos=paths.find(path)
	var row = randi_range(0, (texture.get_height()/32)-1)
	var tex:AtlasTexture = AtlasTexture.new()
	tex.atlas = texture
	tex.region = Rect2(0, row*32, texture.get_width(), 32)
	
	s = SpriteAnim.create_with_texture(tex, 240, 1)
	s=generate_anims(s)
	s.play('idle_down')
	return s
	
static func generate_anims(s):
	s.create_anim('idle_right', range(4, 10))
	s.create_anim('idle_up', range(10, 16))
	s.create_anim('idle_left', range(16, 22))
	s.create_anim('idle_down', range(22, 28))
	
	s.create_anim('walk_right', range(28, 34))
	s.create_anim('walk_up', range(34, 40))
	s.create_anim('walk_left', range(40, 46))
	s.create_anim('walk_down', range(46, 52))
	
	s.create_anim('sit_right', range(52, 58))
	s.create_anim('sit_left', range(58, 64))
	s.create_anim('sit_up', range(10, 16))
	s.create_anim('sit_down', range(22, 28))
	
	s.create_anim('phone', range(64, 76))
	
	s.create_anim('book', range(76, 88))
	
	s.create_anim('catch_right', range(88, 100))
	s.create_anim('catch_up', range(100, 112))
	s.create_anim('catch_left', range(112, 124))
	s.create_anim('catch_down', range(124, 136))
	
	s.create_anim('gift_right', range(136, 146))
	s.create_anim('gift_up', range(146, 156))
	s.create_anim('gift_left', range(156, 166))
	s.create_anim('gift_down', range(166, 176))
	
	s.create_anim('touch_right', range(176, 182), false)
	s.create_anim('touch_up', range(182, 188), false)
	s.create_anim('touch_left', range(188, 194), false)
	s.create_anim('touch_down', range(194, 200), false)
	
	s.create_anim('damage_right', range(228, 231), false)
	s.create_anim('damage_up', range(231, 234), false)
	s.create_anim('damage_left', range(234, 237), false)
	s.create_anim('damage_down', range(237, 240), false)
	return s
