extends Node

class_name Action


static func create_action_key(action_name:String, key:Key):
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
		
	var ev = InputEventKey.new()
	ev.keycode = key
	InputMap.action_add_event(action_name, ev)


static func create_action_mouse(action_name:String, button:MouseButton):
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
		
	var ev = InputEventMouseButton.new()
	ev.button_index = button
	InputMap.action_add_event(action_name, ev)


static func press(action_name:String):
	return Input.is_action_pressed(action_name)

static func press_once(action_name:String):
	return Input.is_action_just_pressed(action_name)
	
static func release(action_name:String):
	return Input.is_action_just_released(action_name)
