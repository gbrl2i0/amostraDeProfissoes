#	##       ##        ##          ######
#	####     ##       ####        ##    ##
#	## ##    ##      ##  ##      ##      ##
#	##  ##   ##     ##    ##     ##      ##
#	##   ##  ##    ##########    ##      ##
#	##    ## ##   ##        ##    ##    ##
#	##     ####  ##          ##    ######

#	##       ##  ##########  ##      ##        ##
#	####   ####  ##           ##    ##        ####
#	## ## ## ##  ##            ##  ##        ##  ##
#	##  ###  ##  ######         ####        ##    ##
#	##       ##  ##            ##  ##      ##########
#	##       ##  ##           ##    ##    ##        ##
#	##       ##  ##########  ##      ##  ##          ##




















extends Node2D

class_name Map

@onready var camadas: Node2D = %Camadas
@onready var marcadores: Node2D = %Marcadores

static func create(path_map:String = ""):
	path_map = "res://danigame/scenes/map/map_cidade.tscn" if path_map == "" else path_map
	var map_scene = load(path_map)
	
	var m:Map = map_scene.instantiate() as Map
	
	return m


func _ready() -> void:
	ClothesGlobal.spawn()
	pass


########################### TILES ###########################
func get_tile_player(player):
	if camadas.get_child_count() < 1:
		return
	
	var ground:TileMapLayer = camadas.get_child(0) as TileMapLayer
	var pos = ground.local_to_map(ground.to_local(player.global_position))
	return { "x": pos.x, "y": pos.y }


func get_tile_free():
	if camadas.get_child_count() < 1:
		return
	
	var ground:TileMapLayer = camadas.get_child(0) as TileMapLayer
	var tile = null
	while not tile:
		tile = ground.get_used_cells().pick_random()
		var data = ground.get_cell_tile_data(tile)
		if not data:
			tile = null
			continue
		
		if data.get_custom_data("ground") != true:
			tile = null
			continue
		
		if tile_is_used(tile):
			tile = null
	
	var pos = ground.map_to_local(tile)
	return { "x": pos.x, "y": pos.y }


func tile_is_used(tile:Vector2i):
	for i in range(camadas.get_child_count()):
		if i > 0:
			var layer:TileMapLayer = camadas.get_child(i) as TileMapLayer
			if layer.get_used_cells().has(tile):
				print("Usado: ", tile, " - ", i)
				return true
	
	return false

########################### MARCADORES ###########################
func get_markers():
	var markers = []
	for m in marcadores.get_children():
		if m is Marker:
			markers.append({
				"x": m.position.x,
				"y": m.position.y,
				"tipo": m.tipo,
				"nome": m.nome,
				"direcao": m.direcao
			})
	
	return markers


func get_markers_by_type(type:String):
	var markers = []
	for m in marcadores.get_children():
		if m is Marker:
			if m.tipo.to_lower() == type.to_lower():
				markers.append({
					"x": m.position.x,
					"y": m.position.y,
					"tipo": m.tipo,
					"nome": m.nome,
					"direcao": m.direcao
				})
	
	return markers


func get_markers_by_name(nome:String):
	var markers = []
	for m in marcadores.get_children():
		if m is Marker:
			if m.nome.to_lower() == nome.to_lower():
				markers.append({
					"x": m.position.x,
					"y": m.position.y,
					"tipo": m.tipo,
					"nome": m.nome,
					"direcao": m.direcao
				})
				
	
	return markers
