extends Control

@onready var empty: TextureRect = $Empty

func _ready() -> void:
	empty.visible = false

func set_heart(status:int):
	if status == 0:
		empty.visible = true
	else:
		empty.visible = false
