extends State

func enter():
	father._tween("scale",Vector2(3,0.00001),0.1)
	father._tween("scale",Vector2(1,1),0.2)
	pass

func update(_delta):
	if Input.is_action_just_pressed("shift"):
		if father._endDialogue():
			statemachine.change_state("walk")

	father._play("idle")
	
	father._handleGravity(_delta)
	#father._handleGravity(_delta)
	pass

func exit():
	pass
