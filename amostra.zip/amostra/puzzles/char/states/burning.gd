extends State
@onready var footsteps: AudioStreamPlayer2D = $"../../footsteps"
var fire = preload("res://fireDispenser/fire_particle.tscn")

var timer = 0.5
func enter():
	father.direction = father.lastDir
	if father.box_check:
		father.box_check.monitoring = false
	father._play("walkPush")
	father.position.y-=8
	pass

func update(_delta):
	
	if father.getGround():
		father.inBelt = true if father.getGround().is_in_group("belt") else false
	timer -= _delta
	if timer<=0:
		statemachine.change_state("walk")
	#in case we just landed, rotation = 0, reffer to airborne state
	father.animated_sprite_2d.rotation = 0
	#what this state does?
	father._handleBurningMovement()
	father._handleSpriteDir()
	father._handleJump()
	var fireInstance = fire.instantiate()
	fireInstance.yMult = -1
	father.add_child(fireInstance)
	#change state when of ground
	father._handleGravity(_delta)
	#father._handleGravity(_delta)
	pass

func exit():
	timer = 0.5
	pass
