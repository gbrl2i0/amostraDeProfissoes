extends State

func enter():
	pass

func update(_delta):

	if father.charIn or father.keyIn:
		father.transparent()
	else:
		father.solid()
	if father.beingPushed:
		statemachine.change_state("push")
		
	pass

func exit():
	pass
