extends State

func enter():
	
	pass

func update(_delta):
	if !father.beingPushed:
		statemachine.change_state("default")
	father.pushed()
	pass

func exit():
	pass
