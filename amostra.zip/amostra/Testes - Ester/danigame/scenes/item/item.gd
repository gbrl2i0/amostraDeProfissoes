extends DisplayObject

class_name Item

const item_scene = preload("res://danigame/scenes/item/item.tscn")

var sprite: Sprite2D
var item_name:String

@onready var sprite_container: Node2D = $SpriteContainer
@onready var area: Area2D = $Area

var pixelart := true:
	set(value):
		pixelart = value
		if sprite:
			sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if value == true else CanvasItem.TEXTURE_FILTER_LINEAR
	get:
		return pixelart


static func create(_item_name:String):
	var item_instance:Item = item_scene.instantiate() as Item
	item_instance.init(_item_name)
	
	return item_instance
	

func init(_item_name:String):
	item_name = _item_name
	var item = DataItem.get_item(item_name)
	if not item:
		print("Não achei " + item_name)
		return
	
	var image = load( DataItem.get_asset(item.group) )
	
	sprite = Sprite2D.new()
	sprite.texture = image
	sprite.hframes = sprite.texture.get_width() / 16
	sprite.vframes = sprite.texture.get_height() / 16
	sprite.frame = item.frame
	pixelart = true
	
	id = item.name
	group = item.group
	info = { "description": item.description, "extra": item.extra, "frame": item.frame }
	
	width = 16
	height = 16


func _ready():
	if not sprite:
		return
	
	sprite_container.add_child(sprite)


func get_inventory():
	var s = "[font_size=20][b]{name}[/b][/font_size]\n{description}"
	return s.format({"name": id, "description": info.description})
