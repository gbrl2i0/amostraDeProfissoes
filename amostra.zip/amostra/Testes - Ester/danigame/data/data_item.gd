extends Node

class_name DataItem

static var items = [
	# Materiais
	{ "frame": 0, "name": "Minério de Cobre", "description": "Metal comum encontrado nas minas", "group": "material", "extra": {} },
	{ "frame": 1, "name": "Minério de Ferro", "description": "Metal incomum encontrado nas minas", "group": "material", "extra": {} },
	{ "frame": 2, "name": "Minério de Ouro", "description": "Metal raro encontrado nas minas", "group": "material", "extra": {} },
	{ "frame": 3, "name": "Minério de Irídio", "description": "Metal muito raro encontrado em meteóros", "group": "material", "extra": {} },
	{ "frame": 4, "name": "Minério de Metal Radioativo", "description": "Metal muito raro encontrado nas minas", "group": "material", "extra": {} },
	{ "frame": 5, "name": "Tronco de Madeira", "description": "Tronco de madeira comum", "group": "material", "extra": {} },
	{ "frame": 6, "name": "Graveto de Madeira", "description": "Graveto de madeira comum", "group": "material", "extra": {} },
	{ "frame": 7, "name": "Folhas de papel", "description": "Você pode escrever nelas", "group": "material", "extra": {} },
	{ "frame": 8, "name": "Pena", "description": "Algum pássaro perdeu isso", "group": "material", "extra": {} },
	{ "frame": 9, "name": "Pedaço de couro", "description": "Um pedaço de tecido", "group": "material", "extra": {} },
	{ "frame": 10, "name": "Fio Vermelho", "description": "Carretel de fio vermelho", "group": "material", "extra": {} },
	{ "frame": 11, "name": "Fio Laranja ", "description": "Carretel de fio laranja", "group": "material", "extra": {} },
	{ "frame": 12, "name": "Fio Amarelo", "description": "Carretel de fio amarelo", "group": "material", "extra": {} },
	{ "frame": 13, "name": "Fio Verde", "description": "Carretel de fio verde", "group": "material", "extra": {} },
	{ "frame": 14, "name": "Fio Azul", "description": "Carretel de fio azul", "group": "material", "extra": {} },
	{ "frame": 15, "name": "Fio Liás", "description": "Carretel de fio Liás", "group": "material", "extra": {} },
	{ "frame": 16, "name": "Fio Roxo", "description": "Carretel de fio roxo", "group": "material", "extra": {} },
	{ "frame": 17, "name": "Fio Ciano", "description": "Carretel de fio Ciano", "group": "material", "extra": {} },
	{ "frame": 18, "name": "Fio Rosa", "description": "Carretel de fio Rosa", "group": "material", "extra": {} },
	{ "frame": 19, "name": "Fio Verde Musgo", "description": "Carretel de fio Verde Musgo", "group": "material", "extra": {} },


	{ "frame": 20, "name": "Barra de Cobre", "description": "Exige 5 Minérios de Cobres para ser criada", "group": "material", "extra": {} },
	{ "frame": 21, "name": "Barra de Ferro", "description": "Exige 5 Minérios de Ferro para ser criada", "group": "material", "extra": {} },
	{ "frame": 22, "name": "Barra de Ouro", "description": "Exige 5 Minérios de Ouro para ser criada", "group": "material", "extra": {} },
	{ "frame": 23, "name": "Barra de Irídio", "description": "Exige 5 Minérios de Irídio para ser criada", "group": "material", "extra": {} },
	{ "frame": 24, "name": "Barra de Metal Radioativo", "description": "Exige 5 Minérios de Metal Radioativo para ser criada", "group": "material", "extra": {} },
	{ "frame": 25, "name": "Galho de madeira", "description": "Um galho comum", "group": "material", "extra": {} },
	{ "frame": 27, "name": "Rolo de papel", "description": "Um rolo de papel", "group": "material", "extra": {} },
	{ "frame": 29, "name": "Carvão", "description": "Um pedaço de carvão", "group": "material", "extra": {} },
	{ "frame": 30, "name": "Agulha Vermelha", "description": "Agulha com linha Vermelha", "group": "material" , "extra": {} },
	{ "frame": 31, "name": "Agulha Laranja", "description": "Agulha com linha Laranja", "group": "material" , "extra": {} },
	{ "frame": 32, "name": "Agulha Amarela", "description": "Agulha com linha Amarela", "group": "material" , "extra": {} },
	{ "frame": 33, "name": "Agulha Verde", "description": "Agulha com linha Verde", "group": "material" , "extra": {} },
	{ "frame": 34, "name": "Agulha Azul", "description": "Agulha com linha Azul", "group": "material" , "extra": {} },
	{ "frame": 35, "name": "Agulha Lilás", "description": "Agulha com linha Lilás", "group": "material" , "extra": {} },
	{ "frame": 36, "name": "Agulha Roxa", "description": "Agulha com linha Roxa", "group": "material" , "extra": {} },
	{ "frame": 37, "name": "Agulha Ciano", "description": "Agulha com linha Ciano", "group": "material" , "extra": {} },
	{ "frame": 38, "name": "Agulha Rosa", "description": "Agulha com linha Rosa", "group": "material" , "extra": {} },
	{ "frame": 39, "name": "Agulha Verde Musgo", "description": "Agulha com linha Verde Musgo", "group": "material" , "extra": {} },


	{ "frame": 40, "name": "Placa de Cobre", "description": "Uma Placa de Cobre simples", "group": "material", "extra": {} },
	{ "frame": 41, "name": "Placa de Ferro", "description": "Uma Placa de Ferro simples", "group": "material", "extra": {} },
	{ "frame": 42, "name": "Placa de Ouro", "description": "Uma Placa de Ouro brilhante", "group": "material", "extra": {} },
	{ "frame": 43, "name": "Placa de Irídio", "description": "Uma Placa de Irídio reluzente", "group": "material", "extra": {} },
	{ "frame": 44, "name": "Placa de Metal Radioativo", "description": "Uma Placa de Metal Radioativo (Parece perigodo)", "group": "material", "extra": {} },
	{ "frame": 46, "name": "Pregos", "description": "Uma Placa de Cobre simples", "group": "material", "extra": {} },
	{ "frame": 47, "name": "Chifre", "description": "Uma Placa de Cobre simples", "group": "material", "extra": {} },
	{ "frame": 49, "name": "Corda", "description": "Uma Placa de Cobre simples", "group": "material", "extra": {} },
	{ "frame": 50, "name": "Fio Siena", "description": "Carretel de fio Siena", "group": "material", "extra": {} },
	{ "frame": 51, "name": "Fio Marrom", "description": "Carretel de fio Marrom", "group": "material", "extra": {} },
	{ "frame": 52, "name": "Fio Preto", "description": "Carretel de fio Preto", "group": "material", "extra": {} },
	{ "frame": 53, "name": "Fio Branco", "description": "Carretel de fio Branco", "group": "material", "extra": {} },


	{ "frame": 60, "name": "Pedra", "description": "Uma edra comum", "extra": {} },
	{ "frame": 61, "name": "Pedra Marrom", "description": "Uma pedra solitária", "group": "material", "extra": {} },
	{ "frame": 62, "name": "Pedra Escura", "description": "Uma pedra solitária", "group": "material", "extra": {} },
	{ "frame": 63, "name": "Pedaço de Argila", "description": "Um pouco de argila", "group": "material", "extra": {} },
	{ "frame": 64, "name": "Linha", "description": "Um fio de linha", "group": "material", "extra": {} },
	{ "frame": 68, "name": "Agulha", "description": "Agulha sem linha", "group": "material" , "extra": {} },
	{ "frame": 70, "name": "Agulha Siena", "description": "Agulha com linha Siena", "group": "material" , "extra": {} },
	{ "frame": 71, "name": "Agulha Marrom", "description": "Agulha com linha Marrom", "group": "material" , "extra": {} },
	{ "frame": 72, "name": "Agulha Preta", "description": "Agulha com linha Preta", "group": "material" , "extra": {} },
	{ "frame": 73, "name": "Agulha Branca", "description": "Agulha com linha Branca", "group": "material" , "extra": {} },


	{ "frame": 80, "name": "Tijolo de Pedra", "description": "Um belo tijolo de pedra branca", "group": "material", "extra": {} },
	{ "frame": 81, "name": "Tijolo de Pedra Marrom", "description": "Um belo tijolo de pedra", "group": "material", "extra": {} },
	{ "frame": 82, "name": "Tijolo Pedra Escura", "description": "Um belo tijolo de pedra negra", "group": "material", "extra": {} },
	{ "frame": 83, "name": "Tijolo de Argila", "description": "Um belo tijolo de argila", "group": "material", "extra": {} },
	{ "frame": 84, "name": "Novelo de fios", "description": "Os gatos adoram!", "group": "material", "extra": {} },
	{ "frame": 85, "name": "Espelho", "description": "Existe alguém mais bonito do que eu?", "group": "material", "extra": {} },
	{ "frame": 86, "name": "Folha", "description": "Uma folha de árvore", "group": "material", "extra": {} },
	{ "frame": 87, "name": "Tecido", "description": "Tecido comum", "group": "material", "extra": {} },
	{ "frame": 88, "name": "Cola", "description": "útil para colar objetos", "group": "material", "extra": {} },
	{ "frame": 90, "name": "Tecido Vermelho", "description":"Tecido na cor Vermelha", "group": "material", "extra": {} },
	{ "frame": 91, "name": "Tecido Laranja", "description":"Tecido na cor Laranja", "group": "material", "extra": {} },
	{ "frame": 92, "name": "Tecido Amarelo", "description":"Tecido na cor Amarela", "group": "material", "extra": {} },
	{ "frame": 93, "name": "Tecido Verde", "description":"Tecido na cor Verde", "group": "material", "extra": {} },
	{ "frame": 94, "name": "Tecido Azul", "description":"Tecido na cor Azul", "group": "material", "extra": {} },
	{ "frame": 95, "name": "Tecido Lilás", "description":"Tecido na cor Lilás", "group": "material", "extra": {} },
	{ "frame": 96, "name": "Tecido Roxo", "description":"Tecido na cor Roxa", "group": "material", "extra": {} },
	{ "frame": 97, "name": "Tecido Ciano", "description":"Tecido na cor Ciano", "group": "material", "extra": {} },
	{ "frame": 98, "name": "Tecido Rosa", "description": "Tecido na cor Rosa", "group": "material", "extra": {} },
	{ "frame": 99, "name": "Tecido Verde Musgo" ,"description": "Tecido na cor Verde Musgo", "group": "material", "extra": {} },


	{ "frame": 100 , "name": "Tinta Vermelha", "description": "Tinta na cor Vermelha", "group": "material", "extra": {} },
	{ "frame": 101 , "name": "Tinta Verde", "description": "Tinta na cor Verde", "group": "material", "extra": {} },
	{ "frame": 102 , "name": "Tinta Roxa", "description": "Tinta na cor Roxa", "group": "material", "extra": {} },
	{ "frame": 103 , "name": "Tinta Verde Musgo", "description": "Tinta na cor Verde Musgo", "group": "material", "extra": {} },
	{ "frame": 104 , "name": "Tinta Preta", "description": "Tinta na cor Preta", "group": "material", "extra": {} },
	{ "frame": 107 , "name": "Flint", "description": "Pedra utilizada para fazer fogo", "group": "material", "extra": {} },
	{ "frame": 110, "name": "Tecido Siena", "description": "Tecido na cor Siena", "group": "material", "extra": {} },
	{ "frame": 111, "name": "Tecido Marrom", "description": "Tecido na cor Marrom", "group": "material", "extra": {} },
	{ "frame": 112, "name": "Tecido Preto", "description": "Tecido na cor Preta","group": "material", "extra":{} },
	{ "frame": 113, "name": "Tecido Branco", "description": "Tecido na cor Branca", "group": "material" , "extra": {} },


	{ "frame": 120, "name": "Tinta Laranja", "description":"Tinta na cor Laranja", "group": "material", "extra": {} },
	{ "frame": 121, "name": "Tinta Azul", "description":"Tinta na cor Azul", "group": "material", "extra": {} },
	{ "frame": 122, "name": "Tinta Ciano", "description":"Tinta na cor Ciano", "group": "material", "extra": {} },
	{ "frame": 123, "name": "Tinta Siena", "description":"Tinta na cor Siena", "group": "material", "extra": {} },
	{ "frame": 124, "name": "Tinta Branca", "description":"Tinta na cor Branca", "group": "material", "extra": {} },
	{ "frame": 125, "name": "Balde de Metal", "description": "Um balde vazio de metal", "group": "material", "extra": {} },


	{ "frame": 140, "name": "Tinta Amarela", "description":"Tinta na cor Amarela", "group": "material", "extra": {} },
	{ "frame": 141, "name": "Tinta Violeta ", "description":"Tinta na cor Violeta", "group": "material", "extra": {} },
	{ "frame": 142, "name": "Tinta Rosa", "description":"Tinta na cor Rosa", "group": "material", "extra": {} },
	{ "frame": 143, "name": "Tinta Marrom", "description":"Tinta na cor Marrom", "group": "material", "extra": {} },
	{ "frame": 144, "name": "Balde de Madeira", "description":"Um balde vazio de madeira", "group": "material", "extra": {} },
	{ "frame": 145, "name": "Pilha", "description":"Usada para dar energia a eletrônicos", "group": "material", "extra": {} },
	
	
	# COMIDAS
	
	
	# PEIXES
	
]


static var assets = {
	"material": "res://danigame/assets/tilesets/materials.png"
}

static func get_item(item_name:String):
	item_name = item_name.to_lower()
	for item in items:
		if item.name.to_lower() == item_name:
			return item
	
	return null


static func get_asset(group:String):
	if not group in assets:
		return
	
	return assets[group]
