extends State
var burning = 1
var fire = preload("res://fireDispenser/fire_particle.tscn")
var brokenSprite = preload("res://assets/boxBroken.png")

func enter():
	father.remove_from_group("boxes")
	
	father.tween = get_tree().create_tween()
	father.tween.tween_property(father.sprite_2d, "modulate", Color(0.3,0.2,0.2,1), 1)
	father.set_collision_layer_value(2, false)
	father.set_collision_layer_value(1, false)
	father.set_collision_mask_value(2, false)
	father.set_collision_mask_value(1, false)
	father.set_collision_layer_value(3, true)
	father.set_collision_mask_value(3, true)
	father.set_collision_mask_value(12, false)
	father.set_collision_layer_value(12, false)
	pass

func update(_delta):
	var fireInstance = fire.instantiate()
	fireInstance.yMult = -1
	father.add_child(fireInstance)
	burning-=_delta
	if burning<=0.5:
		father.changeSpr(brokenSprite)
	if burning<=0:
		statemachine.change_state("smoke")
	pass

func exit():
	pass
