extends CharacterBody2D
class_name mainChar

#speeds
const SPEED = 300.0
const JUMP_VELOCITY = -400.0
@onready var jump_buffer: ShapeCast2D = $jumpBuffer

var inBelt = false
var jumpBuffer = 1
#Selected System
var selectedPOCandidates: Array
var selectedPO:PhysicsBody2D
@onready var selected_list: Label = $CanvasLayer/SelectedList


var selectedDialogue:Node2D
#Char Dimensions
var height = 32
var width = 32
#Direction/ Last, not 0, direction
var direction
var lastDir=1
#Checks if there is ground in front of character
var checkGround = false
@onready var ground_box_check: Area2D = $groundBoxCheck
var animationGroundBoxCheck: AnimationPlayer
var checkGroundBox = false
var checkGroundBoxList = []
#Tweens for animation
var tween
#Text for the dialogue box
var text = preload("res://Text/Textl.tscn")
var instanceText
#The dialogue BOX
@onready var dialogue_box: CanvasLayer = $dialogueBox
#the state MACHINE
@onready var state_machine: StateMachine = $StateMachine
@onready var state_machine_push: StateMachine = $StateMachine/push/StateMachine

#the sprite the character uses (why not change the name?????????? me dum :D)
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
#the collision for the character body .... say that again
@onready var collisionBox: CollisionShape2D = $CollisionShape2D
#the exclamation mark on top of the character... why spanish... Lo sé
@onready var aclamacion: Sprite2D = $aclamacion
#Checks, not only boxes, but pickable objects like keys
@onready var box_check: Area2D = $boxCheck
#soundEffects
#Footsteps soundEffect
@onready var footstepsSnd: AudioStreamPlayer2D = $footsteps

func _ready() -> void:
	for a in ground_box_check.get_children():
		print(a.get_groups())
		if a.is_in_group("animPlayer"):
			animationGroundBoxCheck = a
#Animate the sprite with a tween, suposed to be used in, for example, states
func _tween(property:String = "", value=0, time:float=1.0, object = animated_sprite_2d):
	#create a tween
	tween = get_tree().create_tween()
	tween.tween_property(object, property, value, time)
	return null
	
#Play function in character to substitute the play function in sprite, for convenience
func _play(animName:String):
	animated_sprite_2d.play(animName)
	pass
#Handles the flip_h property for the char
func _handleSpriteDir():
	animated_sprite_2d.flip_h=bool(1-lastDir)
#Handles the velocity.x property for the char, can be costumized for different types of
#movement
func _handleMovement(speedMult:float=1, frictionMult:float=1, mode:int=0):
	direction = Input.get_axis("a", "d")
	if direction:
		lastDir = direction
		if mode == 0:
			velocity.x = direction * SPEED * speedMult
		elif mode == 1:
			if direction and abs(velocity.x)<300:
				velocity.x += direction * SPEED * speedMult
			else:
				velocity.x = move_toward(velocity.x, 300, SPEED*frictionMult)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED*frictionMult)
	if not is_on_floor():
		_tween("rotation", (0.1*direction),0.2)
	move_and_slide()
	pass
#Handles the velocity.y property for the char
func _handleBurningMovement():
	direction = Input.get_axis("a", "d") if Input.get_axis("a", "d") !=0 else direction 
	lastDir = direction
	velocity.x = direction*SPEED*1.2
	move_and_slide()
func _handleJump(jumpMult:float=1):
	if is_on_floor():
		jumpBuffer = 0.1
	if Input.is_action_just_pressed("space") and is_on_floor() or Input.is_action_just_pressed("space") and jumpBuffer>0:
		_tween("scale",Vector2(0.9,1.2),0.1)
		velocity.y = (JUMP_VELOCITY * jumpMult)
	pass
#Handles the velocity.y property for the char when holding a object
func _handleJumpWeighted(jumpMult:float=1, weight: int = 0):
	if is_on_floor():
		jumpBuffer = 0.1
	if true or Input.is_action_just_pressed("space") and is_on_floor() or Input.is_action_just_pressed("space") and jumpBuffer>0:
		_tween("scale",Vector2(1,1),0.1)
		velocity.y = (JUMP_VELOCITY * jumpMult)+weight
		
	
	pass
#Handles the velocity.y property for the char when on air/ not on floor
func _handleGravity(delta:float, gravityMult:float=1):
	if not is_on_floor():
		velocity += get_gravity() * delta * gravityMult
#Handles the "push", holding a object
func _handlePush():
	if selectedPO.is_in_group("boxes"):
		if !selectedPO.is_in_group("key"):
			selectedPO.setBeingPushed(true)
		selectedPO.global_position.x=position.x
		selectedPO.global_position.y=position.y-height
		selectedPO.velocity.y=0
		return selectedPO.is_in_group("boxes")
	return null
#Drops the box in front of the char
func _handleDrop():
	if Input.is_action_just_pressed("s"):
		if not checkGround:
			selectedPO.global_position.x+=(width)*lastDir

		if not checkGroundBox or selectedPO.is_in_group("key"):
			if !selectedPO.is_in_group("key"):
				selectedPO.beingPushed = false
			selectedPO = null
			box_check.monitoring = false
			box_check.monitoring = true
			return true
		else:
			animationGroundBoxCheck.play("RESET")
			animationGroundBoxCheck.play("appear")
			selectedPO.global_position.x = position.x
		return false
#Launches the box, if holding w, the trajetory changes
func _handleLaunch():
	if Input.is_action_just_pressed("shift"):
		if not checkGroundBox or selectedPO.is_in_group("key"):
			if !selectedPO.is_in_group("key"):
				selectedPO.beingPushed = false
			var a = 1.3 if Input.is_action_pressed("w") else 1.0
			var lauchVelocity = Vector2(300/a,-300*a)
			selectedPO.velocity = lauchVelocity*Vector2(lastDir,1)
			selectedPO = null
			box_check.monitoring = false
			box_check.monitoring = true
			return true
		else:
			animationGroundBoxCheck.play("RESET")
			animationGroundBoxCheck.play("appear")
		return false
#instantly gets rid of the exclamation
func _apagarAclamacion():
	aclamacion.visible = false
	_tween("scale", Vector2(1,1), 0.1, aclamacion)
#controls when the exclamation appears
func _manejarAclamacion():
	if selectedPOCandidates or selectedDialogue:
		aclamacion.visible = true
		_tween("scale", Vector2(1.2,1.2), 0.1, aclamacion)
	else:
		aclamacion.visible = false
		_tween("scale", Vector2(1,1), 0.1, aclamacion)
#for now... useless
func _physics_process(_delta: float) -> void:
	if not is_on_floor():
		jumpBuffer-=_delta
	if checkGroundBoxList.size()>0:
		checkGroundBox = true
	else:
		checkGroundBox = false
	updateList()

	#collisionBox.scale = animated_sprite_2d.scale
	pass
#along with end dialogue, this handles the dialogue system
func _handleDialogue():
	if selectedDialogue:
		dialogue_box.visible = true
		instanceText = text.instantiate()
		instanceText.text = selectedDialogue.text
		instanceText.textDuration = selectedDialogue.textDuration
		dialogue_box.add_child(instanceText)
		state_machine.change_state("dialogue")
#ends dialogue
func _endDialogue():
	if instanceText._isRunning():
		instanceText._endText()
	elif !instanceText._isRunning():
		instanceText.queue_free()
		dialogue_box.visible = false
		selectedDialogue.nextText()
		box_check.monitoring = false
		box_check.monitoring = true
		return true

func resetMonitoring():
	box_check.monitoring = false
	box_check.monitoring = true
func getGround():
	if jump_buffer.get_collider(0):
		return jump_buffer.get_collider(0)
	else:
		return null
	
#checks a new pickable object or dialogue
func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("dialogue") and !selectedPO:
		selectedDialogue = body.get_parent()
		
	if body.is_in_group("boxes") and state_machine.active_state.name != "push" and body.is_in_group("boxes"):
		if state_machine.active_state.name != "dialogue":
			selectedDialogue = null
			selectedPOCandidates.append(body)
			
		pass

		

	pass # Replace with function body.

#checks if  pickable object or dialogue got too far
func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.is_in_group("boxes") and state_machine.active_state.name != "push" and body!=self:
		selectedPOCandidates.erase(body)

	if body.is_in_group("dialogue"):
		selectedDialogue = null
	pass # Replace with function body.
func updateList():
	selected_list.text = ""
	selected_list.text += "Velocidade\nX: "+str(velocity.x) +"\nY: "+str(velocity.x) 
	
func _changeState(newState):
	state_machine.change_state(newState)

#checks if there is ground in front of the char
func _on_ground_check_body_entered(body: Node2D) -> void:
	if body.is_class("TileMapLayer"):
		checkGround = true
		pass

#checks if there is ground in front of the char is too far
func _on_ground_check_body_exited(body: Node2D) -> void:
	if body.is_class("TileMapLayer"):
		checkGround = false
		pass



func _on_ground_box_check_body_entered(body: Node2D) -> void:
	if body.is_in_group("boxes") and body != selectedPO:
		checkGroundBoxList.append(body)


func _on_ground_box_check_body_exited(body: Node2D) -> void:
	if body.is_in_group("boxes") and body != selectedPO:
		checkGroundBoxList.erase(body)
