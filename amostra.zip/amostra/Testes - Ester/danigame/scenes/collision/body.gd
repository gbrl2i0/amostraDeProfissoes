extends CollisionShape2D

func set_body_circle(radius:int = 0, translate_x:int = 0, translate_y = 0):
	var real_parent = Danigame.get_display_parent(self)
	if not real_parent:
		return
	
	var width = real_parent.width
	#if "width" in get_parent():
		#width = get_parent().width
	#elif "width" in get_parent().get_parent():
		#width = get_parent().get_parent().width
	#else:
		#return
	
	var _radius = width / 2 if radius == 0 else radius
	
	var _shape:CircleShape2D = CircleShape2D.new()
	_shape.radius = _radius
	shape = _shape
		
	position.x += translate_x
	position.y += translate_y
	
	
func set_body_rect(w:int = 0, h:int = 0, translate_x:int = 0, translate_y = 0):
	var _w = get_parent().width if w == 0 else w
	var _h = get_parent().height if h == 0 else h
	
	var _shape:RectangleShape2D = RectangleShape2D.new()
	_shape.size = Vector2(_w, _h)
	shape = _shape
		
	position.x += translate_x
	position.y += translate_y


func set_enabled(status:bool):
	disabled = not status
