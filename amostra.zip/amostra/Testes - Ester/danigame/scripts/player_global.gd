extends Danigame
var char
var a
var transitioning=false
var transition_timer=0.4
var coords_transition=Vector2(0,0)
var path_transition=""
var skin:Dictionary={"body":"","hair":"","shirt":"","pants":"","shoes":"","accessory":""}

func create_char(clothing):
	print(clothing)
	char=Player.create(clothing,"wasd")
	add_child(char)
	char.set_camera_follow()
	char.func_touch=player_tocou
	
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("reset"):
		remove_child(char)
		char = null
		
		get_tree().change_scene_to_file("res://danigame/scenes/char_creator/char_creator.tscn")
	if transitioning:
		transition_timer-=delta*1
		char.play("idle_"+char.direction)
		
		
	if transition_timer<0 and transitioning:
		char.position=coords_transition
		get_tree().change_scene_to_file(path_transition)
		transitioning=false
		transition_timer=0.4
		char.idle = false
		char.play("idle_"+char.direction)
		
		
		

	
		
func player_tocou(outro,type="",data={}):

	if type=="transition":
		char.idle = true
		transitioning=true
		char.transition_anim.play_anim()
		coords_transition=data.coords
		path_transition=data.local
		char.direction = data.direction
		


		
		pass
	if type == 'read':
		char.is_action=false
		char.play("idle_" + char.last_direction)

		if outro.get_parent().name in ClothesGlobal.clothes:
			if outro.name == "Seu Roberto":
				Dialog.set_dialog(ClothesGlobal.clothes["Seu Roberto"]["fala"][randi_range(0,19)])
				Dialog.start()
			else:
				Dialog.set_dialog(ClothesGlobal.clothes[outro.get_parent().name]["fala"])
				Dialog.start()
		else:
			Dialog.set_dialog(data.text)
			Dialog.start()

			
			
		#AREA DE FUNCIONARIOS#
		if outro.name == "placa_funcionario":
			for a in outro.get_children():
				if a is Interact: 
					a.data.text = "A Área exclusiva para funcionãrios.'"
		if outro.name == "area_funcionario" and outro.data.text == "A 'Área exclusiva para funcionãrios.'":
			a = outro.get_parent()
			a.text = "Observar"
			a.data.text = "Placa... Aqui fala sobre uma 'Área exclusiva para funcionãrios.'"
		if outro.name == "lixo":
			if outro.data.text == "Só lixo":
				outro.data.text = "Ainda é lixo"
			elif outro.data.text != "Ainda é lixo":
				outro.data.text = "Nada mudou"
			elif outro.data.text != "Nada mudou":
				outro.data.text = "Ainda é lixo"
		if outro.name == "computatorlogado":
			outro.data.text = "Thalisson..."
		if outro.name == "absurdo":
			outro.data.text = "Absurdo..."
			
		if outro.name == "extintor":
			outro.text = "Observar"
			outro.data.text = "um aparelho de acionamento manual constituído de um recipiente e acessórios contendo agente extintor, destinado a combater o princípio de incêndio."
		if outro.name.contains("banheiro"):
			outro.text = "Não entrar"
			outro.data.text = "Você não entrou no banheiro"
			
	if type=="sit":
		char.sat_dir=data.get_up_direction
		char.sat_encosto = data.encosto
		char.position=data.position
		char.sit(data.direction)
	pass
