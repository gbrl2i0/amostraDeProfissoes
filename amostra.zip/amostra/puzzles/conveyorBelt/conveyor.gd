extends StaticBody2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var left: RayCast2D = $left
@onready var right: RayCast2D = $right
var hasLeftRight = Vector2(0,0)

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	

	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if left.is_colliding():
		if left.get_collider().is_in_group("belt"):
			hasLeftRight.x = 1
	if right.is_colliding():
		if right.get_collider().is_in_group("belt"):
			hasLeftRight.y = 1
	if hasLeftRight.x - hasLeftRight.y == 0:
		animated_sprite_2d.play("middle")
	elif hasLeftRight.x - hasLeftRight.y > 0:
		animated_sprite_2d.play("right")
	else:
		animated_sprite_2d.play("left")
	pass
