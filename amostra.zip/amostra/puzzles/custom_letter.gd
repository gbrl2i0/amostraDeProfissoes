extends Label
class_name CustomLetter

@export var color = Vector3(255,255,255)
@export var shake = false
var wing = false
@export var posI = Vector2(0,0)



# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var font = preload("res://font/pixelated-wingdings.otf")
	if wing:
		add_theme_font_override("font", font)
	if shake:
		var vector = Vector2(randf_range(0,1),randf_range(0,1))
		position = posI+vector
	add_theme_color_override("font_color", Color(color.x/255, color.y/255, color.z/255, 1))

	pass
