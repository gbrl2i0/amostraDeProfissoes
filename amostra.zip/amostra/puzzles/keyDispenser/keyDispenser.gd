extends Node2D
var tween
@onready var sprite_2d: Sprite2D = $Sprite2D
var key = preload("res://key/key.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func activate():
	tween = get_tree().create_tween()
	tween.tween_property(sprite_2d, "scale", Vector2(1.4,0.6), 0.1)
	tween.tween_property(sprite_2d, "scale", Vector2(1.0,1.0), 0.1)
	var instance = key.instantiate()
	add_child(instance)
