extends Node2D
@onready var sprite_2d: Sprite2D = $Sprite2D
var aliveTime = 1
var aliveTimeStart
var speed = Vector2(0,1)
var yMult = 1
var colors = [
	Color(1,0,0,1), #red
	Color(1,0,0,1), #red
	Color(1,0,0,1), #red
	Color(1,0.4,0,1), #orange
	Color(1,0.4,0,1), #orange
	Color(1,0.4,0,1), #orange
	Color(1,0.4,0,1), #orange
	Color(1,0.4,0,1), #orange
	Color(1,0.4,0,1), #orange
	Color(1,0.8,0,1), #yellow
	Color(1,0.8,0,1), #yellow
	Color(1,0.8,0,1), #yellow
	Color(1,1,1,1), #white
]

var sizes = [
	Vector2(0.7,0.7),
	Vector2(0.6,0.6),
	Vector2(0.5,0.5),
	Vector2(0.4,0.4),
	Vector2(0.3,0.3),
]
# Called when the node enters the scene tree for the first time.
func modulateSpr(color:Color):
	sprite_2d.self_modulate = color

func _ready() -> void:
	aliveTime = randf_range(0.9,1.1)
	aliveTimeStart=aliveTime
	sprite_2d.self_modulate = colors[randi_range(0,colors.size()-1)]
	sprite_2d.scale = sizes[randi_range(0, sizes.size()-1)]
	aliveTime = randf_range(0.6,0.8)
	speed = Vector2(randf_range(-0.8,0.8),randf_range(3.4,4.0)*yMult)

	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	aliveTime -= delta
	if aliveTime<= aliveTimeStart/3:
		modulate.a = aliveTime/aliveTimeStart
	position.x+=speed.x
	position.y+=speed.y
	speed.x-=delta/aliveTimeStart
	speed.y-=delta/aliveTimeStart
	
	if aliveTime<=0:
		queue_free()
	pass
