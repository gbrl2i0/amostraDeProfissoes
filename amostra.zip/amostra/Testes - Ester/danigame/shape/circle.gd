extends DisplayObject

class_name Circle

var center: Vector2
var radius: float
var _color: Color

func _init(px: float, py: float, pradius: float, pcolor: Color):
	center = Vector2(0, 0)
	radius = pradius
	_color = pcolor
	x = px
	y = py

func get_width():
	return radius * 2
	
func get_height():
	return radius * 2


func _draw():
	draw_circle(center, radius, _color)
