extends Node2D
@export var activeTime = 2.0
var timer
@export var cooldown = 1.5
var active = true
var fire = preload("res://fireDispenser/fire_particle.tscn")
@onready var sprite_2d: Sprite2D = $Sprite2D
var cicles = 0
@onready var active_snd: AudioStreamPlayer2D = $activeSnd
@onready var starting_snd: AudioStreamPlayer2D = $startingSnd
@export var mute = true
@onready var area_2d: Area2D = $Area2D

# Called when the node enters the scene tree for the first time.
var tween
func _ready() -> void:
	
	timer = activeTime
	pass # Replace with function body.

func dispense():
	var fireInstance = fire.instantiate()
	add_child(fireInstance)
	pass
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if active:
		if !active_snd.playing and !mute:
			active_snd.play()
		timer-=delta
		
		if timer <=0:
			timer = cooldown
			active = false
			area_2d.monitoring = false
		dispense()
	else:
		active_snd.stop()
		timer-=delta
		var a = 18.892
		if timer<=0.3:
			if !starting_snd.playing and !mute:
				starting_snd.play()
			if cicles%8 == 0:
				modulate = Color(a, a, a,1)
				scale = Vector2(1.1,1.1)
			else:
				modulate = Color(1, 1, 1,1)
				scale = Vector2(1,1)
			cicles+=1
		pass
		if timer <= 0:
			starting_snd.stop()
			scale = Vector2(1,1)
			modulate = Color(1,1,1,1)
			timer = activeTime
			active = true
			area_2d.monitoring = true
	pass


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("burnable"):
		body.burn()
	if body.is_in_group("char"):
		body._changeState("burning")
