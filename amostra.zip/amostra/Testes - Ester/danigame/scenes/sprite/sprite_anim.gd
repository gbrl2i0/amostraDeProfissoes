extends DisplayObject

class_name SpriteAnim

const sprite_scene = preload("res://danigame/scenes/sprite/sprite_anim.tscn")

var sprite: AnimatedSprite2D
var texture:Texture2D
var w: int
var h: int
var sprite_frames:SpriteFrames


var pixelart := true:
	set(value):
		pixelart = value
		if sprite:
			sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if value == true else CanvasItem.TEXTURE_FILTER_LINEAR
	get:
		return pixelart



static func create(path: String, horiz_frames:int, vert_frames:int):
	var sprite_instance:SpriteAnim = sprite_scene.instantiate() as SpriteAnim
	sprite_instance.init(path, horiz_frames, vert_frames)
	
	return sprite_instance


static func create_with_texture(tex:Texture2D, horiz_frames:int, vert_frames:int):
	var sprite_instance:SpriteAnim = sprite_scene.instantiate() as SpriteAnim
	sprite_instance.init(tex, horiz_frames, vert_frames)
	
	return sprite_instance





func init(tex:Variant, horiz_frames:int, vert_frames:int):
	texture = tex if tex is Texture2D else load(tex)
	
	w = texture.get_width() / horiz_frames
	h = texture.get_height() / vert_frames
	
	width = w
	height = h
	
	
	sprite = AnimatedSprite2D.new()
	sprite_frames = SpriteFrames.new()
	sprite.sprite_frames = sprite_frames



func _ready():
	pixelart = true
	add_child(sprite)
	#sprite.position.y = -h/2


func create_anim(anim_name: String, frames: Array, loop:bool = true, frame_rate: int = 8):
	sprite_frames.add_animation(anim_name)
	sprite_frames.set_animation_loop(anim_name, loop)
	sprite_frames.set_animation_speed(anim_name, frame_rate)
	
	for i in frames:
		var pos = get_frame_pos(i)
		var tex:AtlasTexture = AtlasTexture.new()
		tex.atlas = texture
		tex.region = Rect2(pos.px, pos.py, w, h)
		sprite_frames.add_frame(anim_name, tex)
	
	play(anim_name)



func play(anim: String):
	if sprite.sprite_frames.has_animation(anim):
		sprite.play(anim)



func get_frame_pos(frame_number):
	var cols:int = texture.get_width() / w
	
	var px:int = frame_number % cols
	var py:int = frame_number / cols
	
	return {
		"px": px * w,
		"py": py * h
	}
