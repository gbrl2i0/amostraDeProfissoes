extends Node

class_name Player

static func create(texture_index = [-1,-1,-1,-1,-1,-1], keys:String = "arrows"):
	print(texture_index)
	var sprite_anim = DefaultPlayerAnimations.create_all(texture_index)
	
	var keys_options = {
		"arrows": { "left": KEY_LEFT, "right": KEY_RIGHT, "up": KEY_UP, "down": KEY_DOWN },
		"wasd": { "left": KEY_A, "right": KEY_D, "up": KEY_W, "down": KEY_S }
	}
	
	var key = keys_options.wasd if keys == "wasd" else keys_options.arrows
	
	var character:Character = Character.create(sprite_anim)
	character.set_move("left", key.left, 'walk_left', 'idle_left')
	character.set_move("right", key.right, 'walk_right', 'idle_right')
	character.set_move("up", key.up, 'walk_up', 'idle_up')
	character.set_move("down", key.down, 'walk_down', 'idle_down')
	character.set_move("touch", KEY_SPACE, 'touch')
	character.is_default = true
	
	return character
