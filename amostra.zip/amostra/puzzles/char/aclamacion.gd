extends Sprite2D
var time = 0
var posI
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	posI = position.y
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	time+=delta
	position.y = sin(time * 3) * 1.5 + posI
	pass
