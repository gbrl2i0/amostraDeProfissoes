extends State
var smoking =1.4
var fire = preload("res://fireDispenser/fire_particle.tscn")
func enter():
	
	pass

func update(_delta):
	if smoking>1.1:
		var fireInstance = fire.instantiate()
		fireInstance.yMult = -1
		father.add_child(fireInstance)
		fireInstance.modulateSpr(Color(0.7,0.7,0.7,1))
	smoking-=_delta
	if smoking<=0:
		father.queue_free()
	pass

func exit():
	pass
