extends Node2D
var box = preload("res://box/box.tscn")
var tween
@onready var sprite_2d: Sprite2D = $Sprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var instance = box.instantiate()
	add_child(instance)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if get_children().size()==1:
		tween = get_tree().create_tween()
		tween.tween_property(sprite_2d, "scale", Vector2(1.4,0.6), 0.1)
		tween.tween_property(sprite_2d, "scale", Vector2(1.0,1.0), 0.1)
		var instance = box.instantiate()
		add_child(instance)
	pass
func activate(num):
	tween = get_tree().create_tween()
	tween.tween_property(sprite_2d, "scale", Vector2(1.4,0.6), 0.1)
	tween.tween_property(sprite_2d, "scale", Vector2(1.0,1.0), 0.1)
	
	for i in range(0,num):
		var instance = box.instantiate()
		instance.position.y+=32*i
		add_child(instance)
