extends Node2D
@onready var canvas_modulate: CanvasModulate = $CanvasModulate
var scene = preload("res://transition/square_particle.tscn")
var widht = 1152
var height = 648
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	var squareInstance = scene.instantiate()
	squareInstance.position.x = randi_range(0,1152)
	add_child(squareInstance)
	canvas_modulate.color -= Color(_delta*0.5,_delta*0.5,_delta*0.5,0)
	if canvas_modulate.color.r <= 0:
		canvas_modulate.color = Color(0,0,0,1)

	
	pass
