extends Node

class_name Draw

static func line(x1: float, y1: float, x2: float, y2: float, color: Color = "FFFFFF", stroke: float = 1.0, antialiased: bool = false):
	return Line.new(x1, y1, x2, y2, color, stroke, antialiased)
	
static func rectangle(x: float, y: float, w: float, h: float, color: Color = "FFFFFF", stroke: float = 1.0):
	return Rectangle.new(x, y, w, h, color, false, stroke)

static func rectangle_fill(x: float, y: float, w: float, h: float, color: Color = "FFFFFF"):
	return Rectangle.new(x, y, w, h, color, true, -1.0)

static func circle(x: float, y: float, radius: float, color: Color = "FFFFFF"):
	return Circle.new(x, y, radius, color)

static func arc(x:float, y:float, radius:float, color: Color = "FFFFFF", start_angle:float = 0, end_angle:float = 180, points:int = 10, stroke:float = 1.0, antialiased:bool = true):
	return Arc.new(x, y, radius, color, start_angle, end_angle, points, stroke, antialiased)

static func polyline(points: Array, color: Color = "FFFFFF", stroke: float = 1.0, antialiased: bool = false):
	return Polyline.new(float_array_to_Vector2Array(points), color, stroke, antialiased)

static func polyline_fill(points: Array, color: Color = "FFFFFF"):
	return Polygon.new(float_array_to_Vector2Array(points), color)

static func float_array_to_Vector2Array(coords : Array) -> PackedVector2Array:
	var array : PackedVector2Array = []
	for coord in coords:
		array.append(Vector2(coord[0], coord[1]))
	return array
