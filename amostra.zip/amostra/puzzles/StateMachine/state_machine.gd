extends Node
class_name StateMachine
var states:Dictionary = {}
@export var initial_state:Node
var active_state:Node
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var childs = get_children()
	for child in childs:
		child.statemachine = $"."
		child.father = get_parent()
		states[child.name] = child
	change_state(initial_state.name)
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if active_state:
		active_state.update(delta)
	pass

func change_state(new_state:String):
	if active_state:
		active_state.exit()
	active_state = states[new_state]
	active_state.enter()
	pass
