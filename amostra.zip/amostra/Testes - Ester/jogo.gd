extends Danigame

var mapa:Map
var player:Character


func _ready():
	# Mapa
	mapa = Map.create("res://maps/map_corredor_recepcao.tscn")
	add_child(mapa)
	
	# Player
	var marcador = get_marker("Spawn")
	if marcador:
		player = Player.create("res://assets/characters/ester.png")
		player.speed = 100
		player.touch_distance = 32
		player.move_to(marcador.x, marcador.y)
		#player.move_to(32, 32)
		add_child(player)
		player.set_camera_follow()
		player.play('idle_'+marcador.direcao)




func get_marker(_name:String):
	var marcadores = mapa.get_markers_by_name(_name)
	return null if marcadores.size() < 1 else marcadores[0]


func _process(_delta):
	pass
