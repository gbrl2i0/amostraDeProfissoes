extends Node2D
@onready var ball: CharacterBody2D = $CharacterBody2D
@onready var label_1: Label = $Label1
@onready var label_2: Label = $Label2

var dir = 0
var values = [0,0]

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("r"):
		get_tree().reload_current_scene()



func _on_bar_2_area_shape_entered(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	dir = -1
	values[0]+=1
	reset()
	pass # Replace with function body.

func reset():
	label_1.text = (str(values[0]))
	label_2.text = (str(values[1]))
	ball.position=Vector2(0,0)
	ball.dirx=dir
	ball.diry=0
	ball.speed.x=30
	$bar.position.y=0
	$bar2.position.y=0
	pass


func _on_goal_3_area_shape_entered(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	dir = 1
	values[1]+=1
	reset()
	pass # Replace with function body.
