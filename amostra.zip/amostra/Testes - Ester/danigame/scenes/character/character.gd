extends CharacterBody2D

class_name Character

const character_scene:PackedScene = preload("res://danigame/scenes/character/character.tscn")

@onready var sprite_container: Node2D = $SpriteContainer
@onready var area: Area2D = $Area
@onready var body: CollisionShape2D = $Body
@onready var remote_transform_2d: RemoteTransform2D = $RemoteTransform2D
@onready var ray_cast: RayCast2D = %RayCast
var direction_sit=""
var speed = 150
var touch_distance:int = 16
var sprite:Array
var move = {}
#var actions = {}
var is_default = false
var func_area_enter:Callable
var func_area_exit:Callable
var func_touch:Callable

var node_dialog:UIDialog
var node_ui:UIHUD
var func_dialog_finish:Callable
var func_question_finish:Callable

var is_action:bool = false
var next_anim:String
var direction:String = "down"

var is_walking:bool = false
var walk_direction:String = "down"
var walk_speed:int = 25
var walk_max_distance:int = 0
var walk_distance:float = 0.0

var following:Node2D = null

var list_directions = ["left", "right", "up", "down"]
var directions = {
	"left": Vector2(-1, 0),
	"right": Vector2(1, 0),
	"up": Vector2(0, -1),
	"down": Vector2(0, 1),
}
var sat=false
var sat_dir=""
var sat_encosto = false
var idle=false
var transition=preload("res://danigame/scenes/transition/transition.tscn")
var transition_anim
var last_direction=""

var dummie:bool

static func create(s:Array,d:bool=false):
	var character_instance:Character = character_scene.instantiate() as Character
	character_instance.init(s,d)
	
	return character_instance

func init(s:Array,d):
	if sprite:
		sprite=[]
	if dummie:
		dummie=false
	dummie=d
	sprite = s


func _ready():
	transition_anim = transition.instantiate()
	add_child(transition_anim)
	if not sprite:
		return
	for part in sprite:
		sprite_container.add_child(part)
		if sprite.find(part)==2:
			part.position.y+=16
			
	
	var a=2
	if sprite.size()<3:
		a=0
	width = sprite[a].width
	height = sprite[a].height
	
	sprite[a].position.y -= height/2
	area.position.y -= height/2
	body.position.y -= height/2
	remote_transform_2d.position.y -= height/2
	
	var main_scene:Node = get_tree().root.get_child(0)
	node_dialog = main_scene.get_node("Dialog")
	node_ui = main_scene.get_node("HUD")
	
	if is_default:
		set_body_circle(6, 0, 10)
		set_area(0, 0, 5)
	else:
		set_body_circle()
		set_area()
	


func set_camera_follow():
	var main_scene:Node = get_tree().root.get_child(0)
	for node in main_scene.get_children():
		if node is Camera2D:
			
			remote_transform_2d.remote_path = node.get_path()
func set_camera_limit(limits:Array = [-10000000,-10000000,10000000,10000000]):
	var main_scene:Node = get_tree().root.get_child(0)
	for node in main_scene.get_children():
		if node is Camera2D:
			node.limit_left = limits[0]
			node.limit_top = limits[1]
			node.limit_right = limits[2]
			node.limit_down = limits[3]


func set_speed(new_speed:int):
	speed = new_speed


func set_move(dir:String, key:Key, on_anim:String = "", off_anim:String = ""):
	if not ["left", "right", "up", "down", "touch"].has(dir):
		print("ATENÇÃO: Direção não encontrada. Possíveis valores: left, right, top, down, touch")
		return;
		
	var action_name = str(get_instance_id()) + dir
	Action.create_action_key(action_name, key)
	
	move[dir] = {
		"action": action_name,
		"on_anim": on_anim,
		"off_anim": off_anim
	}
#func set_action(action:String, key:Key, function:Callable = print, on_anim:String = "", off_anim:String = ""):
	#var action_name = str(get_instance_id()) + action
	#Action.create_action_key(action_name, key)
	#
	#actions[action] = {
		#"action": action_name,
		#"on_anim": on_anim,
		#"off_anim": off_anim,
		#"function": function
	#}


func _physics_process(delta: float) -> void:
	if Action.press_once("inventory"):
		idle=true
	if idle:
		if Input.is_action_just_pressed("move"):
			idle=false
		play("idle_"+last_direction)
		
	if not sat:
		manage_move(delta)
	elif sat:
		play(direction_sit)
	if sat:
		if Input.is_action_just_pressed(move["up"].action):
			position+=Vector2(10,12)*directions[sat_dir[0]]
			sat=false
		if Input.is_action_just_pressed(move["down"].action):
			position+=Vector2(10,12)*directions[sat_dir[1]]
			sat=false
		if Input.is_action_just_pressed(move["right"].action):
			position+=Vector2(10,12)*directions[sat_dir[2]]
			sat=false
		if Input.is_action_just_pressed(move["left"].action):
			position+=Vector2(10,12)*directions[sat_dir[3]]
			sat=false


func manage_move(delta: float):
	# Gerenciando o deslocamento do personagem
	velocity = Vector2.ZERO
	for dir in ["left", "right", "up", "down"]:
		if dir in move:
			if Input.is_action_pressed(move[dir].action):
				last_direction=dir
				velocity += directions[dir]
				ray_cast.target_position = directions[dir] * touch_distance
				direction = dir
				if Input.is_action_pressed(move["up"].action) and Input.is_action_pressed(move["down"].action) and  Input.is_action_pressed(move["right"].action) and Input.is_action_pressed(move["left"].action):
					play("idle_down")
				elif Input.is_action_pressed(move["up"].action) and Input.is_action_pressed(move["down"].action):
					if Input.is_action_pressed(move["right"].action):
						play(move["right"].on_anim)
					elif Input.is_action_pressed(move["left"].action):
						play(move["left"].on_anim)
					else:
						play("idle_down")
				elif Input.is_action_pressed(move["right"].action) and Input.is_action_pressed(move["left"].action):
					if Input.is_action_pressed(move["up"].action):
						play(move["up"].on_anim)
					elif Input.is_action_pressed(move["down"].action):
						play(move["down"].on_anim)
					else:
						play("idle_right")
				elif Input.is_action_pressed(move["up"].action):
					play(move["up"].on_anim)
				elif Input.is_action_pressed(move["down"].action):
					play(move["down"].on_anim)
				else:
					play(move[dir].on_anim)

			if Input.is_action_just_released(move[dir].action):
				play(move[dir].off_anim)
	
	velocity = velocity.normalized()
	
	velocity *= speed
	
	if is_walking and walk_max_distance > 0:
		velocity = Vector2.ZERO
		
		velocity += directions[walk_direction] * walk_speed
		walk_distance += delta * walk_speed
		if walk_distance >= walk_max_distance or ray_cast.is_colliding():
			change_walk_direction()
	elif following:
		var dir = following.global_position - global_position
		velocity = dir.normalized() * 50
		
		if abs(dir.x) > abs(dir.y):
			play("walk_right" if dir.x >= 0 else "walk_left")
		else:
			play("walk_down" if dir.y >= 0 else "walk_up")
	if not dummie:
		move_and_slide()
		
	# Gerenciando a interação
	#if "touch" in move:
		#if Input.is_action_just_pressed(move["touch"].action):
			#is_action = true
			#if move["touch"].off_anim:
				#next_anim = move["touch"].off_anim+"_"+direction
			#play(move["touch"].on_anim)
			#if func_touch and ray_cast.is_colliding():
				#var target = ray_cast.get_collider()
				#var d_obj = Danigame.get_display_parent(target)
				#if d_obj:
					#func_touch.call( d_obj )
	
	var interact_text = ''
	if func_touch and ray_cast.is_colliding():
		var target = ray_cast.get_collider()
		if target is Interact:
			interact_text = target.text
		elif target is Character:
			interact_text = 'Conversar'
		
		if "touch" in move and Input.is_action_just_pressed(move["touch"].action):
			is_action = true
			if move["touch"].off_anim:
				next_anim = move["touch"].off_anim+"_"+direction
			play(move["touch"].on_anim)
			
			if target is Interact:
				func_touch.call(target, target.type, target.data)
			elif target is Character:
				var d_obj = Danigame.get_display_parent(target)
				if d_obj:
					func_touch.call( d_obj )
					
	if not dummie:
		if not sat:
			z_index=1
			if not node_ui==null:
				node_ui.interact = interact_text
		if sat:
			if sat_encosto:
				z_index = 0
			else:
				z_index = 3
		#if not node_ui==null:
			#node_ui.interact = ""


#func manage_action():
	#for action in actions:
		#if Input.is_action_just_pressed(actions[action].action):
			#is_action = true
			#if actions[action].off_anim:
				#next_anim = actions[action].off_anim+"_"+direction
			#play(actions[action].on_anim)
			#if actions[action].function:
				#actions[action].function.call()
			#break


func damage():
	is_action = true
	play("damage")


func play(anim_name):
	for part in sprite:
		if part and part.has_method('play'):
			if is_action:
				part.play(anim_name+"_"+direction)
				await part.sprite.animation_finished
				is_action = false
				part.play(next_anim)
			else:
				next_anim = anim_name
				part.play(anim_name)



# ********************* COLLISIONS ********************
func set_body_circle(radius:int = 0, translate_x:int = 0, translate_y = 0):
	body.set_body_circle(radius, translate_x, translate_y)
	
	
func set_body_rect(w:int = 0, h:int = 0, translate_x:int = 0, translate_y = 0):
	body.set_body_rect(w, h, translate_x, translate_y)


func set_body_enabled(status:bool):
	body.set_enabled(status)


func set_area(radius:int = 0, translate_x:int = 0, translate_y = 0):
	area.set_area(radius, translate_x, translate_y)


func _on_area_area_entered(_area: Area2D) -> void:
	if func_area_enter:
		func_area_enter.call(Danigame.get_display_parent(_area))


func _on_area_area_exited(_area: Area2D) -> void:
	if func_area_exit:
		func_area_exit.call(Danigame.get_display_parent(_area))


####################################### DIALOG #######################################
func talk():
	if not dialog:
		return
	
	node_dialog.set_dialog(dialog)
	node_dialog.start()
	
	connect_signals_dialog()


func connect_signals_dialog():
	node_dialog.dialog_finished.connect(_on_dialog_finished)
	node_dialog.question_finished.connect(_on_question_finished)

func disconnect_signals_dialog():
	node_dialog.dialog_finished.disconnect(_on_dialog_finished)
	node_dialog.question_finished.disconnect(_on_question_finished)

func _on_dialog_finished():
	if func_dialog_finish:
		func_dialog_finish.call(Danigame.get_display_parent(self))
	disconnect_signals_dialog()

func _on_question_finished(index_answer:int):
	if func_question_finish:
		func_question_finish.call(Danigame.get_display_parent(self), index_answer)
	disconnect_signals_dialog()



####################################### WALK #######################################
func walk_start(max_distance:int = 100, _speed:int = 25):
	walk_max_distance = max_distance
	walk_speed = _speed
	ray_cast.collision_mask = 3
	change_walk_direction()


func walk_stop():
	walk_max_distance = 0
	is_walking = false
	play('idle_down')


func change_walk_direction(): 
	is_walking = false
	var dir = "down"
	while dir == walk_direction:
		dir = list_directions.pick_random()
	walk_direction = dir
	play("idle_" + walk_direction)
	
	walk_distance = 0
	ray_cast.target_position = directions[walk_direction] * touch_distance
	
	await get_tree().create_timer(randi_range(2, 3)).timeout
	play("walk_" + walk_direction)
	is_walking = true


func follow_start(target:Node2D):
	following = target


func follow_stop():
	following = null


func sit(direction:String,status:bool = true):
	is_action=false
	sat=true
	direction_sit=('sit_'+direction)
####################################### PROPRIEDADES ######################################
var id := "":
	set(value): id = value
	get: return id

var group := "":
	set(value): group = value
	get: return group
	
var info := {}:
	set(value): info = value
	get: return info

var x := global_position.x:
	set(value): global_position.x = value
	get: return global_position.x

var y := global_position.y:
	set(value): global_position.y = value
	get: return global_position.y

var scale_x := scale.x:
	set(value): scale.x = value
	get: return scale.x

var scale_y := scale.y:
	set(value): scale.y = value
	get: return scale.x

var angle := rotation_degrees:
	set(value): rotation_degrees = value
	get: return rotation_degrees

var color := Color(1, 1, 1, 1):
	set(value): modulate = color
	get: return modulate
	
var opacity := modulate.a:
	set(value): modulate.a = value
	get: return modulate.a

var width := 0:
	set(value): width = value
	get: return width

var height := 0:
	set(value): height = value
	get: return height

var dialog:Variant

func move_to(_x:int, _y:int):
	global_position = Vector2(_x, _y)

func translate_to(_x:int, _y:int):
	global_position += Vector2(_x, _y)
	
func remove_scene():
	await get_tree().create_timer(0.5).timeout
	get_parent().remove_child(self)

func remove():
	await get_tree().create_timer(0.5).timeout
	queue_free()
