extends CanvasLayer

class_name UIInventory

var slot_scene:PackedScene = load("res://danigame/scenes/ui/slots/slot_item.tscn")

@onready var grid_container: GridContainer = %GridContainer
#@onready var label_description: Label = %LabelDescription
@onready var label_description: RichTextLabel = %LabelDescription

var items := []:
	set(value): items = value
	get(): return items

var is_open:bool = false

func _ready() -> void:
	Action.create_action_key("inventory", KEY_I)
	close()

func _process(_delta: float) -> void:
	if Action.press_once("inventory"):
		if is_open:
			close()
		else:
			open()

func process_items():
	for item in grid_container.get_children():
		grid_container.remove_child(item)
	
	for i in range(items.size()):
		var item = items[i]
		var slot:SlotItem = slot_scene.instantiate() as SlotItem
		slot.init(item, i)
		grid_container.add_child(slot)
		
		slot.item_focus_on.connect(_on_item_focus_on)
		slot.item_focus_off.connect(_on_item_focus_off)
		slot.item_selected.connect(_on_item_selected)
	pass

func open():
	process_items()
	is_open = true
	visible = true
	get_tree().paused = true


func close():
	is_open = false
	visible = false
	get_tree().paused = false


func _on_item_focus_on(description:String):
	label_description.text = description


func _on_item_focus_off():
	label_description.text = ""


func _on_item_selected(item, index):
	var main_scene:Node = get_tree().root.get_child(0)
	if main_scene and main_scene.has_method("item_selected"):
		main_scene.item_selected(item, index)
