extends State

func enter():
	father.transparent()

	pass

func update(_delta):
	pass

func exit():
	pass
