extends Node
class_name State
var statemachine:StateMachine
var father
func enter():
	pass

func update(_delta):
	pass

func exit():
	pass
