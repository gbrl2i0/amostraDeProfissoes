extends DisplayObject

class_name Arc

var center: Vector2
var radius: float
var _color: Color
var start_angle: float
var end_angle: float
var points: int
var stroke: float
var antialiased: bool

func _init(px:float, py:float, pradius:float, pcolor:Color, pstart_angle:float, pend_angle:float, ppoints:int, pstroke:float, pantialiased:bool):
	center = Vector2(0, 0)
	radius = pradius
	_color = pcolor
	start_angle = deg_to_rad(pstart_angle)
	end_angle = deg_to_rad(pend_angle)
	points = ppoints
	stroke = pstroke
	antialiased = pantialiased
	x = px
	y = py

func get_width():
	return radius * 2
	
func get_height():
	return radius * 2


func _draw():
	#draw_arc(center, radius, start_angle, end_angle, points, color, stroke, antialiased)
	draw_arc(center, radius, start_angle, end_angle, points, _color, stroke, antialiased)
