extends CharacterBody2D

class_name Pokemon

const pokemon_scene = preload("res://danigame/scenes/pokemon/pokemon.tscn")

var number:int
var pokemon:SpriteAnim

@onready var sprite_container: Node2D = $SpriteContainer
@onready var area: Area2D = $Area
@onready var body: CollisionShape2D = $Body
@onready var ray_cast: RayCast2D = %RayCast

var touch_distance:int = 32

var is_walking:bool = false
var walk_direction:String = "down"
var walk_speed:int = 25
var walk_max_distance:int = 0
var walk_distance:float = 0.0

var following:Node2D = null

var list_directions = ["left", "right", "up", "down"]
var directions = {
	"left": Vector2(-1, 0),
	"right": Vector2(1, 0),
	"up": Vector2(0, -1),
	"down": Vector2(0, 1),
}



static func create(_num:int):
	return Pokemon.create_by_number(_num)


static func create_by_number(_num:int):
	var poke:Pokemon = pokemon_scene.instantiate() as Pokemon
	poke.init_num(_num)
	
	return poke


static func create_by_name(_name:String):
	var poke:Pokemon = pokemon_scene.instantiate() as Pokemon
	poke.init_name(_name)
	
	return poke


func init_num(_num:int):
	number = _num
	group = "pokemon"
	info = DataPokemon.get_by_num(_num)
	id = info.nome


func init_name(_name:String):
	group = "pokemon"
	info = DataPokemon.get_by_name(_name)
	id = info.nome
	number = info.numero


func _ready() -> void:
	var path = DataPokemon.get_sprite(number)
	var texture:Texture2D = load(path)
	var frameW:int = texture.get_width() / 4
	var frameH:int = texture.get_height() / 4
	
	pokemon = SpriteAnim.create(path, 4, 4)
	pokemon.create_anim("down", range(0, 4))
	pokemon.create_anim("left", range(4, 8))
	pokemon.create_anim("right", range(8, 12))
	pokemon.create_anim("up", range(12, 16))
	pokemon.pixelart = true
	pokemon.sprite.scale = Vector2(0.5, 0.5)
	pokemon.play("down")
	sprite_container.add_child(pokemon)
	
	width = frameW / 2
	height = frameH / 2
	
	set_body_circle(int(width * 0.4))
	set_area(int(width * 0.75))


func _process(delta: float) -> void:
	velocity = Vector2.ZERO
	
	if is_walking and walk_max_distance > 0:
		velocity += directions[walk_direction] * walk_speed
		walk_distance += delta * walk_speed
		if walk_distance >= walk_max_distance or ray_cast.is_colliding():
			change_walk_direction()
	
	elif following:
		var dir = following.global_position - global_position
		velocity = dir.normalized() * 50
		
		if abs(dir.x) > abs(dir.y):
			play("right" if dir.x >= 0 else "left")
		else:
			play("down" if dir.y >= 0 else "up")
		
	move_and_slide()


func play(anim_name:String):
	if pokemon:
		pokemon.play(anim_name)


func get_inventory():
	var _info = info.duplicate(true)
	_info.altura = "%.2f" % (_info.altura / 100.0)
	_info.peso = _info.peso / 1000.0
	_info.tipo = ", ".join(_info.tipo)
	
	var s = "[font_size=20][b]{numero} - {nome}[/b][/font_size]\n"
	s += "ALTURA: {altura}m     PESO: {peso}kg     [{tipo}]\n"
	s += "HP: {hp} | ATK: {atk} | DEF: {def} | SP ATK: {spatk} | SP DEF: {spdef} | SPEED: {speed}"
	return s.format(_info)


####################################### COLLISION #######################################
func set_body_circle(radius:int = 0, translate_x:int = 0, translate_y = 0):
	body.set_body_circle(radius, translate_x, translate_y)
	
	
func set_body_rect(w:int = 0, h:int = 0, translate_x:int = 0, translate_y = 0):
	body.set_body_rect(w, h, translate_x, translate_y)


func set_body_enabled(status:bool):
	body.set_enabled(status)


func set_area(radius:int = 0, translate_x:int = 0, translate_y = 0):
	print(radius)
	area.set_area(radius, translate_x, translate_y)


####################################### WALK #######################################
func walk_start(max_distance:int = 100, _speed:int = 25):
	walk_max_distance = max_distance
	walk_speed = _speed
	ray_cast.collision_mask = 3
	change_walk_direction()


func walk_stop():
	walk_max_distance = 0
	is_walking = false
	play('down')


func change_walk_direction():
	is_walking = false
	
	await get_tree().create_timer(randi_range(2, 5)).timeout
	var dir = list_directions.pick_random()
	walk_distance = 0
	walk_direction = dir
	play(walk_direction)
	is_walking = true
	ray_cast.target_position = directions[walk_direction] * touch_distance


func follow_start(target:Node2D):
	following = target


func follow_stop():
	following = null



####################################### PROPRIEDADES ######################################
var id := "":
	set(value): id = value
	get: return id

var group := "":
	set(value): group = value
	get: return group
	
var info := {}:
	set(value): info = value
	get: return info

var x := global_position.x:
	set(value): global_position.x = value
	get: return global_position.x

var y := global_position.y:
	set(value): global_position.y = value
	get: return global_position.y

var scale_x := scale.x:
	set(value): scale.x = value
	get: return scale.x

var scale_y := scale.y:
	set(value): scale.y = value
	get: return scale.x

var angle := rotation_degrees:
	set(value): rotation_degrees = value
	get: return rotation_degrees

var color := Color(1, 1, 1, 1):
	set(value): modulate = color
	get: return modulate
	
var opacity := modulate.a:
	set(value): modulate.a = value
	get: return modulate.a

var width := 0:
	set(value): width = value
	get: return width

var height := 0:
	set(value): height = value
	get: return height

var dialog:Variant

func move_to(_x:int, _y:int):
	global_position = Vector2(_x, _y)

func translate_to(_x:int, _y:int):
	global_position += Vector2(_x, _y)
	
func remove_scene():
	await get_tree().create_timer(0.5).timeout
	get_parent().remove_child(self)

func remove():
	await get_tree().create_timer(0.5).timeout
	queue_free()
