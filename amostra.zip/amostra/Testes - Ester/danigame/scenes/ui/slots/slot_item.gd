extends Control

class_name SlotItem

signal item_focus_on(description)
signal item_focus_off
signal item_selected(_item, _index)

@onready var texture_rect: TextureRect = %TextureRect
@onready var cursor: TextureRect = %Cursor

var item
var index:int = 0

func init(_item, _index:int = 0):
	item = _item
	index = _index
	

func _ready() -> void:
	cursor.visible = false
	
	if item and "group" in item:
		if item.group == "pokemon":
			var texture:Texture2D = load( DataPokemon.get_sprite(item.info.numero) )
			var w = texture.get_width()
			var h = texture.get_height()
			
			var tex:AtlasTexture = AtlasTexture.new()
			tex.atlas = texture
			tex.region = Rect2(0, 0, w/4, h/4)
			texture_rect.texture = tex
		elif ["material", "comida", "peixe"].has(item.group):
			var texture:Texture2D = load( DataItem.get_asset(item.group) )
			var tex:AtlasTexture = AtlasTexture.new()
			tex.atlas = texture
			tex.region = Rect2((item.info.frame%20)*16, (item.info.frame/20)*16, 16, 16)
			texture_rect.texture = tex
			
	
	#var item = DataItem.get_item("Tecido Verde")
	#var texture = load(DataItem.get_asset(item.group))
	#var tex:AtlasTexture = AtlasTexture.new()
	#tex.atlas = texture
	##print(item.frame, " - ", str((item.frame%20)*16), " - ", str((item.frame/20)*16))
	#tex.region = Rect2((item.frame%20)*16, (item.frame/20)*16, 16, 16)
	#texture_rect.texture = tex
	pass


func _on_color_rect_mouse_entered() -> void:
	cursor.visible = true
	if item.has_method("get_inventory"):
		item_focus_on.emit( item.get_inventory() )


func _on_color_rect_mouse_exited() -> void:
	cursor.visible = false
	item_focus_off.emit()


func _on_color_rect_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed == false:
		item_selected.emit(item, index)
