extends State
var selected = 0
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var line: Line2D = $Line2D

func enter():
	#little animation when entering
	father._tween("scale",Vector2(3,0.00001),0.1)
	father._tween("scale",Vector2(1,1),0.2)
	pass

func update(_delta):
	#in case we just landed, rotation = 0, reffer to airborne state
	father.animated_sprite_2d.rotation = 0
	#what this state does?
	if father.selectedPOCandidates.size()>0:
		if Input.is_action_just_pressed("a"):
			if selected>0:
				father.selectedPOCandidates[selected].modulate = Color("white")
				selected-=1
		if Input.is_action_just_pressed("d"):
			if selected<father.selectedPOCandidates.size()-1:
				father.selectedPOCandidates[selected].modulate = Color("white")
				selected+=1
			
		father.selectedPOCandidates[selected].modulate = Color("ff738aff")
		if Input.is_action_just_pressed("shift") or father.selectedPOCandidates.size() == 1:
			father.selectedPO = father.selectedPOCandidates[selected]
			father.checkGroundBoxList.erase(father.selectedPOCandidates[selected])
			
			father.selectedPOCandidates[selected].modulate = Color("white")
			statemachine.change_state("pushWalk")
			pass
		else:
			sprite.global_position = father.selectedPOCandidates[selected].global_position
			sprite.visible = true
			line.points[0] = father.global_position
			line.points[1] = father.selectedPOCandidates[selected].global_position
			line.visible = true
		father._handleGravity(_delta)
	else:
		statemachine.change_state("walk")
	#father._handleGravity(_delta)
	pass

func exit():
	selected = 0
	if father.selectedPOCandidates.size()>0:
		father.selectedPOCandidates[selected].modulate = Color("white")
	father.selectedPOCandidates = []
	father.resetMonitoring()
	sprite.visible = false
	line.visible = false
	pass
