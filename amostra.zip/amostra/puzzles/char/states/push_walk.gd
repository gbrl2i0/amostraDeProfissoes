extends State
@onready var footsteps: AudioStreamPlayer2D = $"../../footsteps"
var weight = 0
func enter():
	father._apagarAclamacion()
	weight = father.selectedPO.weight
	#little animation when entering
	father._tween("scale",Vector2(3,0.00001),0.1)
	father._tween("scale",Vector2(1,1),0.2)
	if father.box_check:
		father.box_check.monitoring = false
	pass

func update(_delta):
	if father.getGround():
		father.inBelt = true if father.getGround().is_in_group("belt") else false
	
	#in case we just landed, rotation = 0, reffer to airborne state
	father.animated_sprite_2d.rotation = 0
	#what this state does?
	father._handleMovement(0.8,1)
	if Input.is_action_just_pressed("space"):
		statemachine.change_state("pushJumpSquat")
	if !father._handlePush():
		statemachine.change_state("walk")
	father._handleSpriteDir()
	if father.velocity.x!=0:
		father._play("walkPush")
			
	else:
		father._play("idlePush")
	#change state when of ground
	if not father.is_on_floor():
		statemachine.change_state("pushAirborne")
	father._handleGravity(_delta)
	
	if father._handleDrop():
		statemachine.change_state("walk")
	if father._handleLaunch():
		statemachine.change_state("walk")
		pass
	#father._handleGravity(_delta)
	pass

func exit():
	father.resetMonitoring()
	pass
