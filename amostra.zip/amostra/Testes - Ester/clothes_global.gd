extends Node
# corpo olhos cabelo extra1 roupa extra2
var clothes = {
	"Marcelo Loures" = {"clothes" = [1, 0, 147, 52, 74, 0],
	"fala" = "Olá, meu nome é Marcelo Loures, dou aula para as disciplinas Sistemas Digitais e Laboratório de Hardware, e hoje em dia sou coordenador do curso Ciência da Computação. Se você entrar no curso vai poder ajudar a organizar a F01."},
	"Andre Chaves" = {"clothes" = [1, 0, 130, 0, 14, 0],
	"fala" = "Olá, meu nome é André Chaves, dou aula para as disciplinas introdução a computação e Laboratório de programação 2, e hoje em dia sou coordenador do curso Informática."},
	
	"Seu Roberto" = {"clothes" = [2, 0, 110, 52, 18, 7],
	"fala" = [
	"Tratores autônomos já cruzam plantações ao amanhecer.",
	"O solo fala, e os sensores escutam.",
	"Drones substituem os olhos do agricultor.",
	"A colheita é planejada por algoritmos.",
	"Dados crescem junto com o milho.",
	"Agricultura digital, raízes analógicas.",
	"Um tablet na mão, um campo inteiro na tela.",
	"Inteligência artificial prevê a chuva antes das nuvens.",
	"O campo está cada vez mais conectado.",
	"Sementes inteligentes germinam precisão.",
	"Da enxada ao satélite — uma nova era rural.",
	"Cada gota de água é medida, otimizada, preservada.",
	"O futuro se planta com tecnologia.",
	"Máquinas conversam entre si no meio do pasto.",
	"Big data e pequenas mudas, lado a lado.",
	"A produtividade cresce, o desperdício diminui.",
	"O campo virou laboratório a céu aberto.",
	"Robôs colhem tomates com delicadeza cirúrgica.",
	"A tradição encontra o Wi-Fi.",
	"Agricultura 5.0: a natureza em rede."
]
},
	"Jacson" = {"clothes" = [0, 0, 81, 52, 23, 42],
	"fala" = "Olá, meu nome é Jacson e eu sou diretor do IFTM campus Ituiutaba. Se divirta com segurança e responsabilidade."},
	"Geise" = {"clothes" = [2, 0, 32, 42, 18, 37], 
	"fala" = "Olá, meu nome é Geise e eu dou aula de Banco de Dados. Você é uma PESSOA com cara que SE VIRARIA bem aqui no IFTM."}

}


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func spawn():
	var markers = get_tree().current_scene
	if markers:
		markers = markers.get_child(1)
		if markers.name == "Marcadores":
			for marker in markers.get_children():
				var npc = NPC.create_all(clothes[marker.name]["clothes"],true)
				marker.add_child(npc)
				pass
		pass
