extends Node2D

class_name DisplayObject

var id := "":
	set(value): id = value
	get: return id

var group := "":
	set(value): group = value
	get: return group
	
var info := {}:
	set(value): info = value
	get: return info

var x := global_position.x:
	set(value): global_position.x = value
	get: return global_position.x

var y := global_position.y:
	set(value): global_position.y = value
	get: return global_position.y

var scale_x := scale.x:
	set(value): scale.x = value
	get: return scale.x

var scale_y := scale.y:
	set(value): scale.y = value
	get: return scale.x

var angle := rotation_degrees:
	set(value): rotation_degrees = value
	get: return rotation_degrees

var color := Color(1, 1, 1, 1):
	set(value): modulate = color
	get: return modulate
	
var opacity := modulate.a:
	set(value): modulate.a = value
	get: return modulate.a

var width := 0:
	set(value): width = value
	get: return width

var height := 0:
	set(value): height = value
	get: return height

func move_to(_x:int, _y:int):
	global_position = Vector2(_x, _y)

func translate_to(_x:int, _y:int):
	global_position += Vector2(_x, _y)
	
func remove_scene():
	await get_tree().create_timer(0.5).timeout
	get_parent().remove_child(self)

func remove():
	await get_tree().create_timer(0.5).timeout
	queue_free()
