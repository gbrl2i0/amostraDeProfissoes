extends Control
var char
var buttons={}
var clothing=[0,0,0,0,0,0]
var clothing_selector_scene=preload("res://danigame/scenes/char_creator/clothing_selector.tscn")
var selecting
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for botao in $CanvasLayer/wich_part .get_children():
		buttons[botao.name]=botao
	buttons["corpo"].grab_focus()
	show_character(clothing)
	


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func show_character(clothes:Array=[0,0,0,0,0,0]):
	print(clothes)
	$CanvasLayer.remove_child(char)
	char=NPC.create_all(clothes,true)
	char.z_index=1
	$CanvasLayer.add_child(char)
	char.position.y=115
	char.position.x=800
	char.scale=Vector2(4,4)
	
func create_selector(tipo:String):
	
	for child in $CanvasLayer.get_children():
		if "Clothing selector" in child.name:
			$CanvasLayer.remove_child($CanvasLayer.get_node("Clothing selector"))
			
	var instance=clothing_selector_scene.instantiate()
	instance.generate(tipo)
	instance.scale = Vector2(1.2,1.2)
	$CanvasLayer.add_child(instance)
	$CanvasLayer.move_child(instance,1)
	

func _on_corpo_pressed() -> void:
	selecting=0
	create_selector("bodies")
	pass # Replace with function body



func _on_acessorio_pressed() -> void:
	selecting=3
	create_selector("accessories")
	pass # Replace with function body.


func _on_roupa_pressed() -> void:
	selecting=4
	create_selector("outfits")
	pass # Replace with function body.


func _on_cabelo_pressed() -> void:
	selecting=2
	create_selector("hair")
	pass # Replace with function body.


func _on_olhos_pressed() -> void:
	selecting=1
	create_selector("eyes")
	pass # Replace with function body.


func _on_concluido_pressed() -> void:
	print(clothing)
	PlayerGlobal.create_char(clothing)
	PlayerGlobal.char.position+=Vector2(20,20)
	get_tree().change_scene_to_file("res://maps/map_corredor_recepcao.tscn")
	pass # Replace with function body.


func _on_acessorio_2_pressed() -> void:
	selecting=5
	create_selector("accessories")
	pass # Replace with function body.
