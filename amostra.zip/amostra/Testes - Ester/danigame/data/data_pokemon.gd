extends Node

class_name DataPokemon

static var pokemon = [
  {
	"numero": 1,
	"nome": "BULBASAUR",
	"altura": 70,
	"peso": 6900,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 45,
	"atk": 49,
	"def": 49,
	"spatk": 65,
	"spdef": 65,
	"speed": 45,
	"evolucoes": [
	  "BULBASAUR",
	  "IVYSAUR",
	  "VENUSAUR"
	]
  },
  {
	"numero": 2,
	"nome": "IVYSAUR",
	"altura": 100,
	"peso": 13000,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 60,
	"atk": 62,
	"def": 63,
	"spatk": 80,
	"spdef": 80,
	"speed": 60,
	"evolucoes": [
	  "BULBASAUR",
	  "IVYSAUR",
	  "VENUSAUR"
	]
  },
  {
	"numero": 3,
	"nome": "VENUSAUR",
	"altura": 200,
	"peso": 100000,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 80,
	"atk": 82,
	"def": 83,
	"spatk": 100,
	"spdef": 100,
	"speed": 80,
	"evolucoes": [
	  "BULBASAUR",
	  "IVYSAUR",
	  "VENUSAUR"
	]
  },
  {
	"numero": 4,
	"nome": "CHARMANDER",
	"altura": 60,
	"peso": 8500,
	"tipo": [
	  "FIRE"
	],
	"hp": 39,
	"atk": 52,
	"def": 43,
	"spatk": 60,
	"spdef": 50,
	"speed": 65,
	"evolucoes": [
	  "CHARMANDER",
	  "CHARMELEON",
	  "CHARIZARD"
	]
  },
  {
	"numero": 5,
	"nome": "CHARMELEON",
	"altura": 110,
	"peso": 19000,
	"tipo": [
	  "FIRE"
	],
	"hp": 58,
	"atk": 64,
	"def": 58,
	"spatk": 80,
	"spdef": 65,
	"speed": 80,
	"evolucoes": [
	  "CHARMANDER",
	  "CHARMELEON",
	  "CHARIZARD"
	]
  },
  {
	"numero": 6,
	"nome": "CHARIZARD",
	"altura": 170,
	"peso": 90500,
	"tipo": [
	  "FIRE",
	  "FLYING"
	],
	"hp": 78,
	"atk": 84,
	"def": 78,
	"spatk": 109,
	"spdef": 85,
	"speed": 100,
	"evolucoes": [
	  "CHARMANDER",
	  "CHARMELEON",
	  "CHARIZARD"
	]
  },
  {
	"numero": 7,
	"nome": "SQUIRTLE",
	"altura": 50,
	"peso": 9000,
	"tipo": [
	  "WATER"
	],
	"hp": 44,
	"atk": 48,
	"def": 65,
	"spatk": 50,
	"spdef": 64,
	"speed": 43,
	"evolucoes": [
	  "SQUIRTLE",
	  "WARTORTLE",
	  "BLASTOISE"
	]
  },
  {
	"numero": 8,
	"nome": "WARTORTLE",
	"altura": 100,
	"peso": 22500,
	"tipo": [
	  "WATER"
	],
	"hp": 59,
	"atk": 63,
	"def": 80,
	"spatk": 65,
	"spdef": 80,
	"speed": 58,
	"evolucoes": [
	  "SQUIRTLE",
	  "WARTORTLE",
	  "BLASTOISE"
	]
  },
  {
	"numero": 9,
	"nome": "BLASTOISE",
	"altura": 160,
	"peso": 85500,
	"tipo": [
	  "WATER"
	],
	"hp": 79,
	"atk": 83,
	"def": 100,
	"spatk": 85,
	"spdef": 105,
	"speed": 78,
	"evolucoes": [
	  "SQUIRTLE",
	  "WARTORTLE",
	  "BLASTOISE"
	]
  },
  {
	"numero": 10,
	"nome": "CATERPIE",
	"altura": 30,
	"peso": 2900,
	"tipo": [
	  "BUG"
	],
	"hp": 45,
	"atk": 30,
	"def": 35,
	"spatk": 20,
	"spdef": 20,
	"speed": 45,
	"evolucoes": [
	  "CATERPIE",
	  "METAPOD",
	  "BUTTERFREE"
	]
  },
  {
	"numero": 11,
	"nome": "METAPOD",
	"altura": 70,
	"peso": 9900,
	"tipo": [
	  "BUG"
	],
	"hp": 50,
	"atk": 20,
	"def": 55,
	"spatk": 25,
	"spdef": 25,
	"speed": 30,
	"evolucoes": [
	  "CATERPIE",
	  "METAPOD",
	  "BUTTERFREE"
	]
  },
  {
	"numero": 12,
	"nome": "BUTTERFREE",
	"altura": 110,
	"peso": 32000,
	"tipo": [
	  "BUG",
	  "FLYING"
	],
	"hp": 60,
	"atk": 45,
	"def": 50,
	"spatk": 90,
	"spdef": 80,
	"speed": 70,
	"evolucoes": [
	  "CATERPIE",
	  "METAPOD",
	  "BUTTERFREE"
	]
  },
  {
	"numero": 13,
	"nome": "WEEDLE",
	"altura": 30,
	"peso": 3200,
	"tipo": [
	  "BUG",
	  "POISON"
	],
	"hp": 40,
	"atk": 35,
	"def": 30,
	"spatk": 20,
	"spdef": 20,
	"speed": 50,
	"evolucoes": [
	  "WEEDLE",
	  "KAKUNA",
	  "BEEDRILL"
	]
  },
  {
	"numero": 14,
	"nome": "KAKUNA",
	"altura": 60,
	"peso": 10000,
	"tipo": [
	  "BUG",
	  "POISON"
	],
	"hp": 45,
	"atk": 25,
	"def": 50,
	"spatk": 25,
	"spdef": 25,
	"speed": 35,
	"evolucoes": [
	  "WEEDLE",
	  "KAKUNA",
	  "BEEDRILL"
	]
  },
  {
	"numero": 15,
	"nome": "BEEDRILL",
	"altura": 100,
	"peso": 29500,
	"tipo": [
	  "BUG",
	  "POISON"
	],
	"hp": 65,
	"atk": 90,
	"def": 40,
	"spatk": 45,
	"spdef": 80,
	"speed": 75,
	"evolucoes": [
	  "WEEDLE",
	  "KAKUNA",
	  "BEEDRILL"
	]
  },
  {
	"numero": 16,
	"nome": "PIDGEY",
	"altura": 30,
	"peso": 1800,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 40,
	"atk": 45,
	"def": 40,
	"spatk": 35,
	"spdef": 35,
	"speed": 56,
	"evolucoes": [
	  "PIDGEY",
	  "PIDGEOTTO",
	  "PIDGEOT"
	]
  },
  {
	"numero": 17,
	"nome": "PIDGEOTTO",
	"altura": 110,
	"peso": 30000,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 63,
	"atk": 60,
	"def": 55,
	"spatk": 50,
	"spdef": 50,
	"speed": 71,
	"evolucoes": [
	  "PIDGEY",
	  "PIDGEOTTO",
	  "PIDGEOT"
	]
  },
  {
	"numero": 18,
	"nome": "PIDGEOT",
	"altura": 150,
	"peso": 39500,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 83,
	"atk": 80,
	"def": 75,
	"spatk": 70,
	"spdef": 70,
	"speed": 101,
	"evolucoes": [
	  "PIDGEY",
	  "PIDGEOTTO",
	  "PIDGEOT"
	]
  },
  {
	"numero": 19,
	"nome": "RATTATA",
	"altura": 30,
	"peso": 3500,
	"tipo": [
	  "NORMAL"
	],
	"hp": 30,
	"atk": 56,
	"def": 35,
	"spatk": 25,
	"spdef": 35,
	"speed": 72,
	"evolucoes": [
	  "RATTATA",
	  "RATICATE"
	]
  },
  {
	"numero": 20,
	"nome": "RATICATE",
	"altura": 70,
	"peso": 18500,
	"tipo": [
	  "NORMAL"
	],
	"hp": 55,
	"atk": 81,
	"def": 60,
	"spatk": 50,
	"spdef": 70,
	"speed": 97,
	"evolucoes": [
	  "RATTATA",
	  "RATICATE"
	]
  },
  {
	"numero": 21,
	"nome": "SPEAROW",
	"altura": 30,
	"peso": 2000,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 40,
	"atk": 60,
	"def": 30,
	"spatk": 31,
	"spdef": 31,
	"speed": 70,
	"evolucoes": [
	  "SPEAROW",
	  "FEAROW"
	]
  },
  {
	"numero": 22,
	"nome": "FEAROW",
	"altura": 120,
	"peso": 38000,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 65,
	"atk": 90,
	"def": 65,
	"spatk": 61,
	"spdef": 61,
	"speed": 100,
	"evolucoes": [
	  "SPEAROW",
	  "FEAROW"
	]
  },
  {
	"numero": 23,
	"nome": "EKANS",
	"altura": 200,
	"peso": 6900,
	"tipo": [
	  "POISON"
	],
	"hp": 35,
	"atk": 60,
	"def": 44,
	"spatk": 40,
	"spdef": 54,
	"speed": 55,
	"evolucoes": [
	  "EKANS",
	  "ARBOK"
	]
  },
  {
	"numero": 24,
	"nome": "ARBOK",
	"altura": 350,
	"peso": 65000,
	"tipo": [
	  "POISON"
	],
	"hp": 60,
	"atk": 95,
	"def": 69,
	"spatk": 65,
	"spdef": 79,
	"speed": 80,
	"evolucoes": [
	  "EKANS",
	  "ARBOK"
	]
  },
  {
	"numero": 25,
	"nome": "PIKACHU",
	"altura": 40,
	"peso": 6000,
	"tipo": [
	  "ELECTRIC"
	],
	"hp": 35,
	"atk": 55,
	"def": 40,
	"spatk": 50,
	"spdef": 50,
	"speed": 90,
	"evolucoes": [
	  "PICHU",
	  "PIKACHU",
	  "RAICHU"
	]
  },
  {
	"numero": 26,
	"nome": "RAICHU",
	"altura": 80,
	"peso": 30000,
	"tipo": [
	  "ELECTRIC"
	],
	"hp": 60,
	"atk": 90,
	"def": 55,
	"spatk": 90,
	"spdef": 80,
	"speed": 110,
	"evolucoes": [
	  "PICHU",
	  "PIKACHU",
	  "RAICHU"
	]
  },
  {
	"numero": 27,
	"nome": "SANDSHREW",
	"altura": 60,
	"peso": 12000,
	"tipo": [
	  "GROUND"
	],
	"hp": 50,
	"atk": 75,
	"def": 85,
	"spatk": 20,
	"spdef": 30,
	"speed": 40,
	"evolucoes": [
	  "SANDSHREW",
	  "SANDSLASH"
	]
  },
  {
	"numero": 28,
	"nome": "SANDSLASH",
	"altura": 100,
	"peso": 29500,
	"tipo": [
	  "GROUND"
	],
	"hp": 75,
	"atk": 100,
	"def": 110,
	"spatk": 45,
	"spdef": 55,
	"speed": 65,
	"evolucoes": [
	  "SANDSHREW",
	  "SANDSLASH"
	]
  },
  {
	"numero": 29,
	"nome": "NIDORAN-F",
	"altura": 40,
	"peso": 7000,
	"tipo": [
	  "POISON"
	],
	"hp": 55,
	"atk": 47,
	"def": 52,
	"spatk": 40,
	"spdef": 40,
	"speed": 41,
	"evolucoes": [
	  "NIDORAN-F",
	  "NIDORINA",
	  "NIDOQUEEN"
	]
  },
  {
	"numero": 30,
	"nome": "NIDORINA",
	"altura": 80,
	"peso": 20000,
	"tipo": [
	  "POISON"
	],
	"hp": 70,
	"atk": 62,
	"def": 67,
	"spatk": 55,
	"spdef": 55,
	"speed": 56,
	"evolucoes": [
	  "NIDORAN-F",
	  "NIDORINA",
	  "NIDOQUEEN"
	]
  },
  {
	"numero": 31,
	"nome": "NIDOQUEEN",
	"altura": 130,
	"peso": 60000,
	"tipo": [
	  "POISON",
	  "GROUND"
	],
	"hp": 90,
	"atk": 92,
	"def": 87,
	"spatk": 75,
	"spdef": 85,
	"speed": 76,
	"evolucoes": [
	  "NIDORAN-F",
	  "NIDORINA",
	  "NIDOQUEEN"
	]
  },
  {
	"numero": 32,
	"nome": "NIDORAN-M",
	"altura": 50,
	"peso": 9000,
	"tipo": [
	  "POISON"
	],
	"hp": 46,
	"atk": 57,
	"def": 40,
	"spatk": 40,
	"spdef": 40,
	"speed": 50,
	"evolucoes": [
	  "NIDORAN-M",
	  "NIDORINO",
	  "NIDOKING"
	]
  },
  {
	"numero": 33,
	"nome": "NIDORINO",
	"altura": 90,
	"peso": 19500,
	"tipo": [
	  "POISON"
	],
	"hp": 61,
	"atk": 72,
	"def": 57,
	"spatk": 55,
	"spdef": 55,
	"speed": 65,
	"evolucoes": [
	  "NIDORAN-M",
	  "NIDORINO",
	  "NIDOKING"
	]
  },
  {
	"numero": 34,
	"nome": "NIDOKING",
	"altura": 140,
	"peso": 62000,
	"tipo": [
	  "POISON",
	  "GROUND"
	],
	"hp": 81,
	"atk": 102,
	"def": 77,
	"spatk": 85,
	"spdef": 75,
	"speed": 85,
	"evolucoes": [
	  "NIDORAN-M",
	  "NIDORINO",
	  "NIDOKING"
	]
  },
  {
	"numero": 35,
	"nome": "CLEFAIRY",
	"altura": 60,
	"peso": 7500,
	"tipo": [
	  "FAIRY"
	],
	"hp": 70,
	"atk": 45,
	"def": 48,
	"spatk": 60,
	"spdef": 65,
	"speed": 35,
	"evolucoes": [
	  "CLEFFA",
	  "CLEFAIRY",
	  "CLEFABLE"
	]
  },
  {
	"numero": 36,
	"nome": "CLEFABLE",
	"altura": 130,
	"peso": 40000,
	"tipo": [
	  "FAIRY"
	],
	"hp": 95,
	"atk": 70,
	"def": 73,
	"spatk": 95,
	"spdef": 90,
	"speed": 60,
	"evolucoes": [
	  "CLEFFA",
	  "CLEFAIRY",
	  "CLEFABLE"
	]
  },
  {
	"numero": 37,
	"nome": "VULPIX",
	"altura": 60,
	"peso": 9900,
	"tipo": [
	  "FIRE"
	],
	"hp": 38,
	"atk": 41,
	"def": 40,
	"spatk": 50,
	"spdef": 65,
	"speed": 65,
	"evolucoes": [
	  "VULPIX",
	  "NINETALES"
	]
  },
  {
	"numero": 38,
	"nome": "NINETALES",
	"altura": 110,
	"peso": 19900,
	"tipo": [
	  "FIRE"
	],
	"hp": 73,
	"atk": 76,
	"def": 75,
	"spatk": 81,
	"spdef": 100,
	"speed": 100,
	"evolucoes": [
	  "VULPIX",
	  "NINETALES"
	]
  },
  {
	"numero": 39,
	"nome": "JIGGLYPUFF",
	"altura": 50,
	"peso": 5500,
	"tipo": [
	  "NORMAL",
	  "FAIRY"
	],
	"hp": 115,
	"atk": 45,
	"def": 20,
	"spatk": 45,
	"spdef": 25,
	"speed": 20,
	"evolucoes": [
	  "IGGLYBUFF",
	  "JIGGLYPUFF",
	  "WIGGLYTUFF"
	]
  },
  {
	"numero": 40,
	"nome": "WIGGLYTUFF",
	"altura": 100,
	"peso": 12000,
	"tipo": [
	  "NORMAL",
	  "FAIRY"
	],
	"hp": 140,
	"atk": 70,
	"def": 45,
	"spatk": 85,
	"spdef": 50,
	"speed": 45,
	"evolucoes": [
	  "IGGLYBUFF",
	  "JIGGLYPUFF",
	  "WIGGLYTUFF"
	]
  },
  {
	"numero": 41,
	"nome": "ZUBAT",
	"altura": 80,
	"peso": 7500,
	"tipo": [
	  "POISON",
	  "FLYING"
	],
	"hp": 40,
	"atk": 45,
	"def": 35,
	"spatk": 30,
	"spdef": 40,
	"speed": 55,
	"evolucoes": [
	  "ZUBAT",
	  "GOLBAT",
	  "CROBAT"
	]
  },
  {
	"numero": 42,
	"nome": "GOLBAT",
	"altura": 160,
	"peso": 55000,
	"tipo": [
	  "POISON",
	  "FLYING"
	],
	"hp": 75,
	"atk": 80,
	"def": 70,
	"spatk": 65,
	"spdef": 75,
	"speed": 90,
	"evolucoes": [
	  "ZUBAT",
	  "GOLBAT",
	  "CROBAT"
	]
  },
  {
	"numero": 43,
	"nome": "ODDISH",
	"altura": 50,
	"peso": 5400,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 45,
	"atk": 50,
	"def": 55,
	"spatk": 75,
	"spdef": 65,
	"speed": 30,
	"evolucoes": [
	  "ODDISH",
	  "GLOOM",
	  "VILEPLUME"
	]
  },
  {
	"numero": 44,
	"nome": "GLOOM",
	"altura": 80,
	"peso": 8600,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 60,
	"atk": 65,
	"def": 70,
	"spatk": 85,
	"spdef": 75,
	"speed": 40,
	"evolucoes": [
	  "ODDISH",
	  "GLOOM",
	  "VILEPLUME"
	]
  },
  {
	"numero": 45,
	"nome": "VILEPLUME",
	"altura": 120,
	"peso": 18600,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 75,
	"atk": 80,
	"def": 85,
	"spatk": 110,
	"spdef": 90,
	"speed": 50,
	"evolucoes": [
	  "ODDISH",
	  "GLOOM",
	  "VILEPLUME"
	]
  },
  {
	"numero": 46,
	"nome": "PARAS",
	"altura": 30,
	"peso": 5400,
	"tipo": [
	  "BUG",
	  "GRASS"
	],
	"hp": 35,
	"atk": 70,
	"def": 55,
	"spatk": 45,
	"spdef": 55,
	"speed": 25,
	"evolucoes": [
	  "PARAS",
	  "PARASECT"
	]
  },
  {
	"numero": 47,
	"nome": "PARASECT",
	"altura": 100,
	"peso": 29500,
	"tipo": [
	  "BUG",
	  "GRASS"
	],
	"hp": 60,
	"atk": 95,
	"def": 80,
	"spatk": 60,
	"spdef": 80,
	"speed": 30,
	"evolucoes": [
	  "PARAS",
	  "PARASECT"
	]
  },
  {
	"numero": 48,
	"nome": "VENONAT",
	"altura": 100,
	"peso": 30000,
	"tipo": [
	  "BUG",
	  "POISON"
	],
	"hp": 60,
	"atk": 55,
	"def": 50,
	"spatk": 40,
	"spdef": 55,
	"speed": 45,
	"evolucoes": [
	  "VENONAT",
	  "VENOMOTH"
	]
  },
  {
	"numero": 49,
	"nome": "VENOMOTH",
	"altura": 150,
	"peso": 12500,
	"tipo": [
	  "BUG",
	  "POISON"
	],
	"hp": 70,
	"atk": 65,
	"def": 60,
	"spatk": 90,
	"spdef": 75,
	"speed": 90,
	"evolucoes": [
	  "VENONAT",
	  "VENOMOTH"
	]
  },
  {
	"numero": 50,
	"nome": "DIGLETT",
	"altura": 20,
	"peso": 800,
	"tipo": [
	  "GROUND"
	],
	"hp": 10,
	"atk": 55,
	"def": 25,
	"spatk": 35,
	"spdef": 45,
	"speed": 95,
	"evolucoes": [
	  "DIGLETT",
	  "DUGTRIO"
	]
  },
  {
	"numero": 51,
	"nome": "DUGTRIO",
	"altura": 70,
	"peso": 33300,
	"tipo": [
	  "GROUND"
	],
	"hp": 35,
	"atk": 100,
	"def": 50,
	"spatk": 50,
	"spdef": 70,
	"speed": 120,
	"evolucoes": [
	  "DIGLETT",
	  "DUGTRIO"
	]
  },
  {
	"numero": 52,
	"nome": "MEOWTH",
	"altura": 40,
	"peso": 4200,
	"tipo": [
	  "NORMAL"
	],
	"hp": 40,
	"atk": 45,
	"def": 35,
	"spatk": 40,
	"spdef": 40,
	"speed": 90,
	"evolucoes": [
	  "MEOWTH",
	  "PERSIAN"
	]
  },
  {
	"numero": 53,
	"nome": "PERSIAN",
	"altura": 100,
	"peso": 32000,
	"tipo": [
	  "NORMAL"
	],
	"hp": 65,
	"atk": 70,
	"def": 60,
	"spatk": 65,
	"spdef": 65,
	"speed": 115,
	"evolucoes": [
	  "MEOWTH",
	  "PERSIAN"
	]
  },
  {
	"numero": 54,
	"nome": "PSYDUCK",
	"altura": 80,
	"peso": 19600,
	"tipo": [
	  "WATER"
	],
	"hp": 50,
	"atk": 52,
	"def": 48,
	"spatk": 65,
	"spdef": 50,
	"speed": 55,
	"evolucoes": [
	  "PSYDUCK",
	  "GOLDUCK"
	]
  },
  {
	"numero": 55,
	"nome": "GOLDUCK",
	"altura": 170,
	"peso": 76600,
	"tipo": [
	  "WATER"
	],
	"hp": 80,
	"atk": 82,
	"def": 78,
	"spatk": 95,
	"spdef": 80,
	"speed": 85,
	"evolucoes": [
	  "PSYDUCK",
	  "GOLDUCK"
	]
  },
  {
	"numero": 56,
	"nome": "MANKEY",
	"altura": 50,
	"peso": 28000,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 40,
	"atk": 80,
	"def": 35,
	"spatk": 35,
	"spdef": 45,
	"speed": 70,
	"evolucoes": [
	  "MANKEY",
	  "PRIMEAPE"
	]
  },
  {
	"numero": 57,
	"nome": "PRIMEAPE",
	"altura": 100,
	"peso": 32000,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 65,
	"atk": 105,
	"def": 60,
	"spatk": 60,
	"spdef": 70,
	"speed": 95,
	"evolucoes": [
	  "MANKEY",
	  "PRIMEAPE"
	]
  },
  {
	"numero": 58,
	"nome": "GROWLITHE",
	"altura": 70,
	"peso": 19000,
	"tipo": [
	  "FIRE"
	],
	"hp": 55,
	"atk": 70,
	"def": 45,
	"spatk": 70,
	"spdef": 50,
	"speed": 60,
	"evolucoes": [
	  "GROWLITHE",
	  "ARCANINE"
	]
  },
  {
	"numero": 59,
	"nome": "ARCANINE",
	"altura": 190,
	"peso": 155000,
	"tipo": [
	  "FIRE"
	],
	"hp": 90,
	"atk": 110,
	"def": 80,
	"spatk": 100,
	"spdef": 80,
	"speed": 95,
	"evolucoes": [
	  "GROWLITHE",
	  "ARCANINE"
	]
  },
  {
	"numero": 60,
	"nome": "POLIWAG",
	"altura": 60,
	"peso": 12400,
	"tipo": [
	  "WATER"
	],
	"hp": 40,
	"atk": 50,
	"def": 40,
	"spatk": 40,
	"spdef": 40,
	"speed": 90,
	"evolucoes": [
	  "POLIWAG",
	  "POLIWHIRL",
	  "POLIWRATH"
	]
  },
  {
	"numero": 61,
	"nome": "POLIWHIRL",
	"altura": 100,
	"peso": 20000,
	"tipo": [
	  "WATER"
	],
	"hp": 65,
	"atk": 65,
	"def": 65,
	"spatk": 50,
	"spdef": 50,
	"speed": 90,
	"evolucoes": [
	  "POLIWAG",
	  "POLIWHIRL",
	  "POLIWRATH"
	]
  },
  {
	"numero": 62,
	"nome": "POLIWRATH",
	"altura": 130,
	"peso": 54000,
	"tipo": [
	  "WATER",
	  "FIGHTING"
	],
	"hp": 90,
	"atk": 95,
	"def": 95,
	"spatk": 70,
	"spdef": 90,
	"speed": 70,
	"evolucoes": [
	  "POLIWAG",
	  "POLIWHIRL",
	  "POLIWRATH"
	]
  },
  {
	"numero": 63,
	"nome": "ABRA",
	"altura": 90,
	"peso": 19500,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 25,
	"atk": 20,
	"def": 15,
	"spatk": 105,
	"spdef": 55,
	"speed": 90,
	"evolucoes": [
	  "ABRA",
	  "KADABRA",
	  "ALAKAZAM"
	]
  },
  {
	"numero": 64,
	"nome": "KADABRA",
	"altura": 130,
	"peso": 56500,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 40,
	"atk": 35,
	"def": 30,
	"spatk": 120,
	"spdef": 70,
	"speed": 105,
	"evolucoes": [
	  "ABRA",
	  "KADABRA",
	  "ALAKAZAM"
	]
  },
  {
	"numero": 65,
	"nome": "ALAKAZAM",
	"altura": 150,
	"peso": 48000,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 55,
	"atk": 50,
	"def": 45,
	"spatk": 135,
	"spdef": 95,
	"speed": 120,
	"evolucoes": [
	  "ABRA",
	  "KADABRA",
	  "ALAKAZAM"
	]
  },
  {
	"numero": 66,
	"nome": "MACHOP",
	"altura": 80,
	"peso": 19500,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 70,
	"atk": 80,
	"def": 50,
	"spatk": 35,
	"spdef": 35,
	"speed": 35,
	"evolucoes": [
	  "MACHOP",
	  "MACHOKE",
	  "MACHAMP"
	]
  },
  {
	"numero": 67,
	"nome": "MACHOKE",
	"altura": 150,
	"peso": 70500,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 80,
	"atk": 100,
	"def": 70,
	"spatk": 50,
	"spdef": 60,
	"speed": 45,
	"evolucoes": [
	  "MACHOP",
	  "MACHOKE",
	  "MACHAMP"
	]
  },
  {
	"numero": 68,
	"nome": "MACHAMP",
	"altura": 160,
	"peso": 130000,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 90,
	"atk": 130,
	"def": 80,
	"spatk": 65,
	"spdef": 85,
	"speed": 55,
	"evolucoes": [
	  "MACHOP",
	  "MACHOKE",
	  "MACHAMP"
	]
  },
  {
	"numero": 69,
	"nome": "BELLSPROUT",
	"altura": 70,
	"peso": 4000,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 50,
	"atk": 75,
	"def": 35,
	"spatk": 70,
	"spdef": 30,
	"speed": 40,
	"evolucoes": [
	  "BELLSPROUT",
	  "WEEPINBELL",
	  "VICTREEBEL"
	]
  },
  {
	"numero": 70,
	"nome": "WEEPINBELL",
	"altura": 100,
	"peso": 6400,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 65,
	"atk": 90,
	"def": 50,
	"spatk": 85,
	"spdef": 45,
	"speed": 55,
	"evolucoes": [
	  "BELLSPROUT",
	  "WEEPINBELL",
	  "VICTREEBEL"
	]
  },
  {
	"numero": 71,
	"nome": "VICTREEBEL",
	"altura": 170,
	"peso": 15500,
	"tipo": [
	  "GRASS",
	  "POISON"
	],
	"hp": 80,
	"atk": 105,
	"def": 65,
	"spatk": 100,
	"spdef": 70,
	"speed": 70,
	"evolucoes": [
	  "BELLSPROUT",
	  "WEEPINBELL",
	  "VICTREEBEL"
	]
  },
  {
	"numero": 72,
	"nome": "TENTACOOL",
	"altura": 90,
	"peso": 45500,
	"tipo": [
	  "WATER",
	  "POISON"
	],
	"hp": 40,
	"atk": 40,
	"def": 35,
	"spatk": 50,
	"spdef": 100,
	"speed": 70,
	"evolucoes": [
	  "TENTACOOL",
	  "TENTACRUEL"
	]
  },
  {
	"numero": 73,
	"nome": "TENTACRUEL",
	"altura": 160,
	"peso": 55000,
	"tipo": [
	  "WATER",
	  "POISON"
	],
	"hp": 80,
	"atk": 70,
	"def": 65,
	"spatk": 80,
	"spdef": 120,
	"speed": 100,
	"evolucoes": [
	  "TENTACOOL",
	  "TENTACRUEL"
	]
  },
  {
	"numero": 74,
	"nome": "GEODUDE",
	"altura": 40,
	"peso": 20000,
	"tipo": [
	  "ROCK",
	  "GROUND"
	],
	"hp": 40,
	"atk": 80,
	"def": 100,
	"spatk": 30,
	"spdef": 30,
	"speed": 20,
	"evolucoes": [
	  "GEODUDE",
	  "GRAVELER",
	  "GOLEM"
	]
  },
  {
	"numero": 75,
	"nome": "GRAVELER",
	"altura": 100,
	"peso": 105000,
	"tipo": [
	  "ROCK",
	  "GROUND"
	],
	"hp": 55,
	"atk": 95,
	"def": 115,
	"spatk": 45,
	"spdef": 45,
	"speed": 35,
	"evolucoes": [
	  "GEODUDE",
	  "GRAVELER",
	  "GOLEM"
	]
  },
  {
	"numero": 76,
	"nome": "GOLEM",
	"altura": 140,
	"peso": 300000,
	"tipo": [
	  "ROCK",
	  "GROUND"
	],
	"hp": 80,
	"atk": 120,
	"def": 130,
	"spatk": 55,
	"spdef": 65,
	"speed": 45,
	"evolucoes": [
	  "GEODUDE",
	  "GRAVELER",
	  "GOLEM"
	]
  },
  {
	"numero": 77,
	"nome": "PONYTA",
	"altura": 100,
	"peso": 30000,
	"tipo": [
	  "FIRE"
	],
	"hp": 50,
	"atk": 85,
	"def": 55,
	"spatk": 65,
	"spdef": 65,
	"speed": 90,
	"evolucoes": [
	  "PONYTA",
	  "RAPIDASH"
	]
  },
  {
	"numero": 78,
	"nome": "RAPIDASH",
	"altura": 170,
	"peso": 95000,
	"tipo": [
	  "FIRE"
	],
	"hp": 65,
	"atk": 100,
	"def": 70,
	"spatk": 80,
	"spdef": 80,
	"speed": 105,
	"evolucoes": [
	  "PONYTA",
	  "RAPIDASH"
	]
  },
  {
	"numero": 79,
	"nome": "SLOWPOKE",
	"altura": 120,
	"peso": 36000,
	"tipo": [
	  "WATER",
	  "PSYCHIC"
	],
	"hp": 90,
	"atk": 65,
	"def": 65,
	"spatk": 40,
	"spdef": 40,
	"speed": 15,
	"evolucoes": [
	  "SLOWPOKE",
	  "SLOWBRO"
	]
  },
  {
	"numero": 80,
	"nome": "SLOWBRO",
	"altura": 160,
	"peso": 78500,
	"tipo": [
	  "WATER",
	  "PSYCHIC"
	],
	"hp": 95,
	"atk": 75,
	"def": 110,
	"spatk": 100,
	"spdef": 80,
	"speed": 30,
	"evolucoes": [
	  "SLOWPOKE",
	  "SLOWBRO"
	]
  },
  {
	"numero": 81,
	"nome": "MAGNEMITE",
	"altura": 30,
	"peso": 6000,
	"tipo": [
	  "ELECTRIC",
	  "STEEL"
	],
	"hp": 25,
	"atk": 35,
	"def": 70,
	"spatk": 95,
	"spdef": 55,
	"speed": 45,
	"evolucoes": [
	  "MAGNEMITE",
	  "MAGNETON",
	  "MAGNEZONE"
	]
  },
  {
	"numero": 82,
	"nome": "MAGNETON",
	"altura": 100,
	"peso": 60000,
	"tipo": [
	  "ELECTRIC",
	  "STEEL"
	],
	"hp": 50,
	"atk": 60,
	"def": 95,
	"spatk": 120,
	"spdef": 70,
	"speed": 70,
	"evolucoes": [
	  "MAGNEMITE",
	  "MAGNETON",
	  "MAGNEZONE"
	]
  },
  {
	"numero": 83,
	"nome": "FARFETCHD",
	"altura": 80,
	"peso": 15000,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 52,
	"atk": 90,
	"def": 55,
	"spatk": 58,
	"spdef": 62,
	"speed": 60,
	"evolucoes": [
	  "FARFETCHD",
	  "SIRFETCHD"
	]
  },
  {
	"numero": 84,
	"nome": "DODUO",
	"altura": 140,
	"peso": 39200,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 35,
	"atk": 85,
	"def": 45,
	"spatk": 35,
	"spdef": 35,
	"speed": 75,
	"evolucoes": [
	  "DODUO",
	  "DODRIO"
	]
  },
  {
	"numero": 85,
	"nome": "DODRIO",
	"altura": 180,
	"peso": 85200,
	"tipo": [
	  "NORMAL",
	  "FLYING"
	],
	"hp": 60,
	"atk": 110,
	"def": 70,
	"spatk": 60,
	"spdef": 60,
	"speed": 110,
	"evolucoes": [
	  "DODUO",
	  "DODRIO"
	]
  },
  {
	"numero": 86,
	"nome": "SEEL",
	"altura": 110,
	"peso": 90000,
	"tipo": [
	  "WATER"
	],
	"hp": 65,
	"atk": 45,
	"def": 55,
	"spatk": 45,
	"spdef": 70,
	"speed": 45,
	"evolucoes": [
	  "SEEL",
	  "DEWGONG"
	]
  },
  {
	"numero": 87,
	"nome": "DEWGONG",
	"altura": 170,
	"peso": 120000,
	"tipo": [
	  "WATER",
	  "ICE"
	],
	"hp": 90,
	"atk": 70,
	"def": 80,
	"spatk": 70,
	"spdef": 95,
	"speed": 70,
	"evolucoes": [
	  "SEEL",
	  "DEWGONG"
	]
  },
  {
	"numero": 88,
	"nome": "GRIMER",
	"altura": 90,
	"peso": 30000,
	"tipo": [
	  "POISON"
	],
	"hp": 80,
	"atk": 80,
	"def": 50,
	"spatk": 40,
	"spdef": 50,
	"speed": 25,
	"evolucoes": [
	  "GRIMER",
	  "MUK"
	]
  },
  {
	"numero": 89,
	"nome": "MUK",
	"altura": 120,
	"peso": 30000,
	"tipo": [
	  "POISON"
	],
	"hp": 105,
	"atk": 105,
	"def": 75,
	"spatk": 65,
	"spdef": 100,
	"speed": 50,
	"evolucoes": [
	  "GRIMER",
	  "MUK"
	]
  },
  {
	"numero": 90,
	"nome": "SHELLDER",
	"altura": 30,
	"peso": 4000,
	"tipo": [
	  "WATER"
	],
	"hp": 30,
	"atk": 65,
	"def": 100,
	"spatk": 45,
	"spdef": 25,
	"speed": 40,
	"evolucoes": [
	  "SHELLDER",
	  "CLOYSTER"
	]
  },
  {
	"numero": 91,
	"nome": "CLOYSTER",
	"altura": 150,
	"peso": 132500,
	"tipo": [
	  "WATER",
	  "ICE"
	],
	"hp": 50,
	"atk": 95,
	"def": 180,
	"spatk": 85,
	"spdef": 45,
	"speed": 70,
	"evolucoes": [
	  "SHELLDER",
	  "CLOYSTER"
	]
  },
  {
	"numero": 92,
	"nome": "GASTLY",
	"altura": 130,
	"peso": 100,
	"tipo": [
	  "GHOST",
	  "POISON"
	],
	"hp": 30,
	"atk": 35,
	"def": 30,
	"spatk": 100,
	"spdef": 35,
	"speed": 80,
	"evolucoes": [
	  "GASTLY",
	  "HAUNTER",
	  "GENGAR"
	]
  },
  {
	"numero": 93,
	"nome": "HAUNTER",
	"altura": 160,
	"peso": 100,
	"tipo": [
	  "GHOST",
	  "POISON"
	],
	"hp": 45,
	"atk": 50,
	"def": 45,
	"spatk": 115,
	"spdef": 55,
	"speed": 95,
	"evolucoes": [
	  "GASTLY",
	  "HAUNTER",
	  "GENGAR"
	]
  },
  {
	"numero": 94,
	"nome": "GENGAR",
	"altura": 150,
	"peso": 40500,
	"tipo": [
	  "GHOST",
	  "POISON"
	],
	"hp": 60,
	"atk": 65,
	"def": 60,
	"spatk": 130,
	"spdef": 75,
	"speed": 110,
	"evolucoes": [
	  "GASTLY",
	  "HAUNTER",
	  "GENGAR"
	]
  },
  {
	"numero": 95,
	"nome": "ONIX",
	"altura": 880,
	"peso": 210000,
	"tipo": [
	  "ROCK",
	  "GROUND"
	],
	"hp": 35,
	"atk": 45,
	"def": 160,
	"spatk": 30,
	"spdef": 45,
	"speed": 70,
	"evolucoes": [
	  "ONIX",
	  "STEELIX"
	]
  },
  {
	"numero": 96,
	"nome": "DROWZEE",
	"altura": 100,
	"peso": 32400,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 60,
	"atk": 48,
	"def": 45,
	"spatk": 43,
	"spdef": 90,
	"speed": 42,
	"evolucoes": [
	  "DROWZEE",
	  "HYPNO"
	]
  },
  {
	"numero": 97,
	"nome": "HYPNO",
	"altura": 160,
	"peso": 75600,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 85,
	"atk": 73,
	"def": 70,
	"spatk": 73,
	"spdef": 115,
	"speed": 67,
	"evolucoes": [
	  "DROWZEE",
	  "HYPNO"
	]
  },
  {
	"numero": 98,
	"nome": "KRABBY",
	"altura": 40,
	"peso": 6500,
	"tipo": [
	  "WATER"
	],
	"hp": 30,
	"atk": 105,
	"def": 90,
	"spatk": 25,
	"spdef": 25,
	"speed": 50,
	"evolucoes": [
	  "KRABBY",
	  "KINGLER"
	]
  },
  {
	"numero": 99,
	"nome": "KINGLER",
	"altura": 130,
	"peso": 60000,
	"tipo": [
	  "WATER"
	],
	"hp": 55,
	"atk": 130,
	"def": 115,
	"spatk": 50,
	"spdef": 50,
	"speed": 75,
	"evolucoes": [
	  "KRABBY",
	  "KINGLER"
	]
  },
  {
	"numero": 100,
	"nome": "VOLTORB",
	"altura": 50,
	"peso": 10400,
	"tipo": [
	  "ELECTRIC"
	],
	"hp": 40,
	"atk": 30,
	"def": 50,
	"spatk": 55,
	"spdef": 55,
	"speed": 100,
	"evolucoes": [
	  "VOLTORB",
	  "ELECTRODE"
	]
  },
  {
	"numero": 101,
	"nome": "ELECTRODE",
	"altura": 120,
	"peso": 66600,
	"tipo": [
	  "ELECTRIC"
	],
	"hp": 60,
	"atk": 50,
	"def": 70,
	"spatk": 80,
	"spdef": 80,
	"speed": 150,
	"evolucoes": [
	  "VOLTORB",
	  "ELECTRODE"
	]
  },
  {
	"numero": 102,
	"nome": "EXEGGCUTE",
	"altura": 40,
	"peso": 2500,
	"tipo": [
	  "GRASS",
	  "PSYCHIC"
	],
	"hp": 60,
	"atk": 40,
	"def": 80,
	"spatk": 60,
	"spdef": 45,
	"speed": 40,
	"evolucoes": [
	  "EXEGGCUTE",
	  "EXEGGUTOR"
	]
  },
  {
	"numero": 103,
	"nome": "EXEGGUTOR",
	"altura": 200,
	"peso": 120000,
	"tipo": [
	  "GRASS",
	  "PSYCHIC"
	],
	"hp": 95,
	"atk": 95,
	"def": 85,
	"spatk": 125,
	"spdef": 75,
	"speed": 55,
	"evolucoes": [
	  "EXEGGCUTE",
	  "EXEGGUTOR"
	]
  },
  {
	"numero": 104,
	"nome": "CUBONE",
	"altura": 40,
	"peso": 6500,
	"tipo": [
	  "GROUND"
	],
	"hp": 50,
	"atk": 50,
	"def": 95,
	"spatk": 40,
	"spdef": 50,
	"speed": 35,
	"evolucoes": [
	  "CUBONE",
	  "MAROWAK"
	]
  },
  {
	"numero": 105,
	"nome": "MAROWAK",
	"altura": 100,
	"peso": 45000,
	"tipo": [
	  "GROUND"
	],
	"hp": 60,
	"atk": 80,
	"def": 110,
	"spatk": 50,
	"spdef": 80,
	"speed": 45,
	"evolucoes": [
	  "CUBONE",
	  "MAROWAK"
	]
  },
  {
	"numero": 106,
	"nome": "HITMONLEE",
	"altura": 150,
	"peso": 49800,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 50,
	"atk": 120,
	"def": 53,
	"spatk": 35,
	"spdef": 110,
	"speed": 87,
	"evolucoes": [
	  "TYROGUE",
	  "HITMONLEE"
	]
  },
  {
	"numero": 107,
	"nome": "HITMONCHAN",
	"altura": 140,
	"peso": 50200,
	"tipo": [
	  "FIGHTING"
	],
	"hp": 50,
	"atk": 105,
	"def": 79,
	"spatk": 35,
	"spdef": 110,
	"speed": 76,
	"evolucoes": [
	  ""
	]
  },
  {
	"numero": 108,
	"nome": "LICKITUNG",
	"altura": 120,
	"peso": 65500,
	"tipo": [
	  "NORMAL"
	],
	"hp": 90,
	"atk": 55,
	"def": 75,
	"spatk": 60,
	"spdef": 75,
	"speed": 30,
	"evolucoes": [
	  "LICKITUNG",
	  "LICKILICKY"
	]
  },
  {
	"numero": 109,
	"nome": "KOFFING",
	"altura": 60,
	"peso": 1000,
	"tipo": [
	  "POISON"
	],
	"hp": 40,
	"atk": 65,
	"def": 95,
	"spatk": 60,
	"spdef": 45,
	"speed": 35,
	"evolucoes": [
	  "KOFFING",
	  "WEEZING"
	]
  },
  {
	"numero": 110,
	"nome": "WEEZING",
	"altura": 120,
	"peso": 9500,
	"tipo": [
	  "POISON"
	],
	"hp": 65,
	"atk": 90,
	"def": 120,
	"spatk": 85,
	"spdef": 70,
	"speed": 60,
	"evolucoes": [
	  "KOFFING",
	  "WEEZING"
	]
  },
  {
	"numero": 111,
	"nome": "RHYHORN",
	"altura": 100,
	"peso": 115000,
	"tipo": [
	  "GROUND",
	  "ROCK"
	],
	"hp": 80,
	"atk": 85,
	"def": 95,
	"spatk": 30,
	"spdef": 30,
	"speed": 25,
	"evolucoes": [
	  "RHYHORN",
	  "RHYDON",
	  "RHYPERIOR"
	]
  },
  {
	"numero": 112,
	"nome": "RHYDON",
	"altura": 190,
	"peso": 120000,
	"tipo": [
	  "GROUND",
	  "ROCK"
	],
	"hp": 105,
	"atk": 130,
	"def": 120,
	"spatk": 45,
	"spdef": 45,
	"speed": 40,
	"evolucoes": [
	  "RHYHORN",
	  "RHYDON",
	  "RHYPERIOR"
	]
  },
  {
	"numero": 113,
	"nome": "CHANSEY",
	"altura": 110,
	"peso": 34600,
	"tipo": [
	  "NORMAL"
	],
	"hp": 250,
	"atk": 5,
	"def": 5,
	"spatk": 35,
	"spdef": 105,
	"speed": 50,
	"evolucoes": [
	  "HAPPINY",
	  "CHANSEY",
	  "BLISSEY"
	]
  },
  {
	"numero": 114,
	"nome": "TANGELA",
	"altura": 100,
	"peso": 35000,
	"tipo": [
	  "GRASS"
	],
	"hp": 65,
	"atk": 55,
	"def": 115,
	"spatk": 100,
	"spdef": 40,
	"speed": 60,
	"evolucoes": [
	  "TANGELA",
	  "TANGROWTH"
	]
  },
  {
	"numero": 115,
	"nome": "KANGASKHAN",
	"altura": 220,
	"peso": 80000,
	"tipo": [
	  "NORMAL"
	],
	"hp": 105,
	"atk": 95,
	"def": 80,
	"spatk": 40,
	"spdef": 80,
	"speed": 90,
	"evolucoes": [
	  "KANGASKHAN"
	]
  },
  {
	"numero": 116,
	"nome": "HORSEA",
	"altura": 40,
	"peso": 8000,
	"tipo": [
	  "WATER"
	],
	"hp": 30,
	"atk": 40,
	"def": 70,
	"spatk": 70,
	"spdef": 25,
	"speed": 60,
	"evolucoes": [
	  "HORSEA",
	  "SEADRA",
	  "KINGDRA"
	]
  },
  {
	"numero": 117,
	"nome": "SEADRA",
	"altura": 120,
	"peso": 25000,
	"tipo": [
	  "WATER"
	],
	"hp": 55,
	"atk": 65,
	"def": 95,
	"spatk": 95,
	"spdef": 45,
	"speed": 85,
	"evolucoes": [
	  "HORSEA",
	  "SEADRA",
	  "KINGDRA"
	]
  },
  {
	"numero": 118,
	"nome": "GOLDEEN",
	"altura": 60,
	"peso": 15000,
	"tipo": [
	  "WATER"
	],
	"hp": 45,
	"atk": 67,
	"def": 60,
	"spatk": 35,
	"spdef": 50,
	"speed": 63,
	"evolucoes": [
	  "GOLDEEN",
	  "SEAKING"
	]
  },
  {
	"numero": 119,
	"nome": "SEAKING",
	"altura": 130,
	"peso": 39000,
	"tipo": [
	  "WATER"
	],
	"hp": 80,
	"atk": 92,
	"def": 65,
	"spatk": 65,
	"spdef": 80,
	"speed": 68,
	"evolucoes": [
	  "GOLDEEN",
	  "SEAKING"
	]
  },
  {
	"numero": 120,
	"nome": "STARYU",
	"altura": 80,
	"peso": 34500,
	"tipo": [
	  "WATER"
	],
	"hp": 30,
	"atk": 45,
	"def": 55,
	"spatk": 70,
	"spdef": 55,
	"speed": 85,
	"evolucoes": [
	  "STARYU",
	  "STARMIE"
	]
  },
  {
	"numero": 121,
	"nome": "STARMIE",
	"altura": 110,
	"peso": 80000,
	"tipo": [
	  "WATER",
	  "PSYCHIC"
	],
	"hp": 60,
	"atk": 75,
	"def": 85,
	"spatk": 100,
	"spdef": 85,
	"speed": 115,
	"evolucoes": [
	  "STARYU",
	  "STARMIE"
	]
  },
  {
	"numero": 122,
	"nome": "MR-MIME",
	"altura": 130,
	"peso": 54500,
	"tipo": [
	  "PSYCHIC",
	  "FAIRY"
	],
	"hp": 40,
	"atk": 45,
	"def": 65,
	"spatk": 100,
	"spdef": 120,
	"speed": 90,
	"evolucoes": [
	  "MIME-JR",
	  "MR-MIME",
	  "MR-RIME"
	]
  },
  {
	"numero": 123,
	"nome": "SCYTHER",
	"altura": 150,
	"peso": 56000,
	"tipo": [
	  "BUG",
	  "FLYING"
	],
	"hp": 70,
	"atk": 110,
	"def": 80,
	"spatk": 55,
	"spdef": 80,
	"speed": 105,
	"evolucoes": [
	  "SCYTHER",
	  "SCIZOR"
	]
  },
  {
	"numero": 124,
	"nome": "JYNX",
	"altura": 140,
	"peso": 40600,
	"tipo": [
	  "ICE",
	  "PSYCHIC"
	],
	"hp": 65,
	"atk": 50,
	"def": 35,
	"spatk": 115,
	"spdef": 95,
	"speed": 95,
	"evolucoes": [
	  "SMOOCHUM",
	  "JYNX"
	]
  },
  {
	"numero": 125,
	"nome": "ELECTABUZZ",
	"altura": 110,
	"peso": 30000,
	"tipo": [
	  "ELECTRIC"
	],
	"hp": 65,
	"atk": 83,
	"def": 57,
	"spatk": 95,
	"spdef": 85,
	"speed": 105,
	"evolucoes": [
	  "ELEKID",
	  "ELECTABUZZ",
	  "ELECTIVIRE"
	]
  },
  {
	"numero": 126,
	"nome": "MAGMAR",
	"altura": 130,
	"peso": 44500,
	"tipo": [
	  "FIRE"
	],
	"hp": 65,
	"atk": 95,
	"def": 57,
	"spatk": 100,
	"spdef": 85,
	"speed": 93,
	"evolucoes": [
	  "MAGBY",
	  "MAGMAR",
	  "MAGMORTAR"
	]
  },
  {
	"numero": 127,
	"nome": "PINSIR",
	"altura": 150,
	"peso": 55000,
	"tipo": [
	  "BUG"
	],
	"hp": 65,
	"atk": 125,
	"def": 100,
	"spatk": 55,
	"spdef": 70,
	"speed": 85,
	"evolucoes": [
	  "PINSIR"
	]
  },
  {
	"numero": 128,
	"nome": "TAUROS",
	"altura": 140,
	"peso": 88400,
	"tipo": [
	  "NORMAL"
	],
	"hp": 75,
	"atk": 100,
	"def": 95,
	"spatk": 40,
	"spdef": 70,
	"speed": 110,
	"evolucoes": [
	  "TAUROS"
	]
  },
  {
	"numero": 129,
	"nome": "MAGIKARP",
	"altura": 90,
	"peso": 10000,
	"tipo": [
	  "WATER"
	],
	"hp": 20,
	"atk": 10,
	"def": 55,
	"spatk": 15,
	"spdef": 20,
	"speed": 80,
	"evolucoes": [
	  "MAGIKARP",
	  "GYARADOS"
	]
  },
  {
	"numero": 130,
	"nome": "GYARADOS",
	"altura": 650,
	"peso": 235000,
	"tipo": [
	  "WATER",
	  "FLYING"
	],
	"hp": 95,
	"atk": 125,
	"def": 79,
	"spatk": 60,
	"spdef": 100,
	"speed": 81,
	"evolucoes": [
	  "MAGIKARP",
	  "GYARADOS"
	]
  },
  {
	"numero": 131,
	"nome": "LAPRAS",
	"altura": 250,
	"peso": 220000,
	"tipo": [
	  "WATER",
	  "ICE"
	],
	"hp": 130,
	"atk": 85,
	"def": 80,
	"spatk": 85,
	"spdef": 95,
	"speed": 60,
	"evolucoes": [
	  "LAPRAS"
	]
  },
  {
	"numero": 132,
	"nome": "DITTO",
	"altura": 30,
	"peso": 4000,
	"tipo": [
	  "NORMAL"
	],
	"hp": 48,
	"atk": 48,
	"def": 48,
	"spatk": 48,
	"spdef": 48,
	"speed": 48,
	"evolucoes": [
	  "DITTO"
	]
  },
  {
	"numero": 133,
	"nome": "EEVEE",
	"altura": 30,
	"peso": 6500,
	"tipo": [
	  "NORMAL"
	],
	"hp": 55,
	"atk": 55,
	"def": 50,
	"spatk": 45,
	"spdef": 65,
	"speed": 55,
	"evolucoes": [
	  "EEVEE",
	  "VAPOREON"
	]
  },
  {
	"numero": 134,
	"nome": "VAPOREON",
	"altura": 100,
	"peso": 29000,
	"tipo": [
	  "WATER"
	],
	"hp": 130,
	"atk": 65,
	"def": 60,
	"spatk": 110,
	"spdef": 95,
	"speed": 65,
	"evolucoes": [
	  "EEVEE",
	  "VAPOREON"
	]
  },
  {
	"numero": 135,
	"nome": "JOLTEON",
	"altura": 80,
	"peso": 24500,
	"tipo": [
	  "ELECTRIC"
	],
	"hp": 65,
	"atk": 65,
	"def": 60,
	"spatk": 110,
	"spdef": 95,
	"speed": 130,
	"evolucoes": [
	  ""
	]
  },
  {
	"numero": 136,
	"nome": "FLAREON",
	"altura": 90,
	"peso": 25000,
	"tipo": [
	  "FIRE"
	],
	"hp": 65,
	"atk": 130,
	"def": 60,
	"spatk": 95,
	"spdef": 110,
	"speed": 65,
	"evolucoes": [
	  ""
	]
  },
  {
	"numero": 137,
	"nome": "PORYGON",
	"altura": 80,
	"peso": 36500,
	"tipo": [
	  "NORMAL"
	],
	"hp": 65,
	"atk": 60,
	"def": 70,
	"spatk": 85,
	"spdef": 75,
	"speed": 40,
	"evolucoes": [
	  "PORYGON",
	  "PORYGON2",
	  "PORYGON-Z"
	]
  },
  {
	"numero": 138,
	"nome": "OMANYTE",
	"altura": 40,
	"peso": 7500,
	"tipo": [
	  "ROCK",
	  "WATER"
	],
	"hp": 35,
	"atk": 40,
	"def": 100,
	"spatk": 90,
	"spdef": 55,
	"speed": 35,
	"evolucoes": [
	  "OMANYTE",
	  "OMASTAR"
	]
  },
  {
	"numero": 139,
	"nome": "OMASTAR",
	"altura": 100,
	"peso": 35000,
	"tipo": [
	  "ROCK",
	  "WATER"
	],
	"hp": 70,
	"atk": 60,
	"def": 125,
	"spatk": 115,
	"spdef": 70,
	"speed": 55,
	"evolucoes": [
	  "OMANYTE",
	  "OMASTAR"
	]
  },
  {
	"numero": 140,
	"nome": "KABUTO",
	"altura": 50,
	"peso": 11500,
	"tipo": [
	  "ROCK",
	  "WATER"
	],
	"hp": 30,
	"atk": 80,
	"def": 90,
	"spatk": 55,
	"spdef": 45,
	"speed": 55,
	"evolucoes": [
	  "KABUTO",
	  "KABUTOPS"
	]
  },
  {
	"numero": 141,
	"nome": "KABUTOPS",
	"altura": 130,
	"peso": 40500,
	"tipo": [
	  "ROCK",
	  "WATER"
	],
	"hp": 60,
	"atk": 115,
	"def": 105,
	"spatk": 65,
	"spdef": 70,
	"speed": 80,
	"evolucoes": [
	  "KABUTO",
	  "KABUTOPS"
	]
  },
  {
	"numero": 142,
	"nome": "AERODACTYL",
	"altura": 180,
	"peso": 59000,
	"tipo": [
	  "ROCK",
	  "FLYING"
	],
	"hp": 80,
	"atk": 105,
	"def": 65,
	"spatk": 60,
	"spdef": 75,
	"speed": 130,
	"evolucoes": [
	  "AERODACTYL"
	]
  },
  {
	"numero": 143,
	"nome": "SNORLAX",
	"altura": 210,
	"peso": 460000,
	"tipo": [
	  "NORMAL"
	],
	"hp": 160,
	"atk": 110,
	"def": 65,
	"spatk": 65,
	"spdef": 110,
	"speed": 30,
	"evolucoes": [
	  "MUNCHLAX",
	  "SNORLAX"
	]
  },
  {
	"numero": 144,
	"nome": "ARTICUNO",
	"altura": 170,
	"peso": 55400,
	"tipo": [
	  "ICE",
	  "FLYING"
	],
	"hp": 90,
	"atk": 85,
	"def": 100,
	"spatk": 95,
	"spdef": 125,
	"speed": 85,
	"evolucoes": [
	  "ARTICUNO"
	]
  },
  {
	"numero": 145,
	"nome": "ZAPDOS",
	"altura": 160,
	"peso": 52600,
	"tipo": [
	  "ELECTRIC",
	  "FLYING"
	],
	"hp": 90,
	"atk": 90,
	"def": 85,
	"spatk": 125,
	"spdef": 90,
	"speed": 100,
	"evolucoes": [
	  "ZAPDOS"
	]
  },
  {
	"numero": 146,
	"nome": "MOLTRES",
	"altura": 200,
	"peso": 60000,
	"tipo": [
	  "FIRE",
	  "FLYING"
	],
	"hp": 90,
	"atk": 100,
	"def": 90,
	"spatk": 125,
	"spdef": 85,
	"speed": 90,
	"evolucoes": [
	  "MOLTRES"
	]
  },
  {
	"numero": 147,
	"nome": "DRATINI",
	"altura": 180,
	"peso": 3300,
	"tipo": [
	  "DRAGON"
	],
	"hp": 41,
	"atk": 64,
	"def": 45,
	"spatk": 50,
	"spdef": 50,
	"speed": 50,
	"evolucoes": [
	  "DRATINI",
	  "DRAGONAIR",
	  "DRAGONITE"
	]
  },
  {
	"numero": 148,
	"nome": "DRAGONAIR",
	"altura": 400,
	"peso": 16500,
	"tipo": [
	  "DRAGON"
	],
	"hp": 61,
	"atk": 84,
	"def": 65,
	"spatk": 70,
	"spdef": 70,
	"speed": 70,
	"evolucoes": [
	  "DRATINI",
	  "DRAGONAIR",
	  "DRAGONITE"
	]
  },
  {
	"numero": 149,
	"nome": "DRAGONITE",
	"altura": 220,
	"peso": 210000,
	"tipo": [
	  "DRAGON",
	  "FLYING"
	],
	"hp": 91,
	"atk": 134,
	"def": 95,
	"spatk": 100,
	"spdef": 100,
	"speed": 80,
	"evolucoes": [
	  "DRATINI",
	  "DRAGONAIR",
	  "DRAGONITE"
	]
  },
  {
	"numero": 150,
	"nome": "MEWTWO",
	"altura": 200,
	"peso": 122000,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 106,
	"atk": 110,
	"def": 90,
	"spatk": 154,
	"spdef": 90,
	"speed": 130,
	"evolucoes": [
	  "MEWTWO"
	]
  },
  {
	"numero": 151,
	"nome": "MEW",
	"altura": 40,
	"peso": 4000,
	"tipo": [
	  "PSYCHIC"
	],
	"hp": 100,
	"atk": 100,
	"def": 100,
	"spatk": 100,
	"spdef": 100,
	"speed": 100,
	"evolucoes": [
	  "MEW"
	]
  }
]

static func get_by_name(_name:String):
	_name = _name.to_lower()
	for poke in pokemon:
		if poke.nome.to_lower() == _name:
			return poke
	
	return null

static func get_by_num(num:int):
	if num < 1 or num > pokemon.size():
		num = 1
	
	return pokemon[num-1]

static func get_sprite(num:int):
	return "res://danigame/assets/pokemon/"+str(num)+".png"
