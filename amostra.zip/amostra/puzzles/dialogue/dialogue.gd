extends Node2D
@export var texts:Array = []
var text
@export var textDuration=0.0
@export var wing = false
@export var color = Vector3(255,255,255)
var currentText = 0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	text = texts[currentText]
	pass
func nextText():
	if currentText < texts.size()-1:
		currentText+=1
