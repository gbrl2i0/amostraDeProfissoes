extends Node2D
@export var activations = 1
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("boxes"):
		if !visible:
			get_parent().activate(activations)
			body.burn()
			queue_free()
		else:
			get_parent().activate()
		pass
	pass # Replace with function body.
