extends Area2D

class_name Interact

## Nome da interação a ser executada ("read", "sit", "open", transition, etc) 
@export var type:String
## Texto exibido no jogo, indicando ao jogador que interação será realizada. Deixe em branco para não exibir.
@export var text:String
## Conjunto de informações adicionais passadas ao interagir
@export var data:Dictionary

func _ready() -> void:
	if type=="sit":
		data.position=global_position
		pass
	pass
