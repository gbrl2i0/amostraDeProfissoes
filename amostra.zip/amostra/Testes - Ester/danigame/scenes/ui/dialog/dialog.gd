extends CanvasLayer

class_name UIDialog

signal dialog_finished
signal question_finished(index_answer)

enum DialogType {NONE, TEXT, QUESTION}

@onready var label_dialog: RichTextLabel = %LabelDialog
@onready var cursor_next: TextureRect = $Control/MarginContainer/NinePatchRect/MarginContainer2/CursorNext
@onready var control: Control = $Control

var dialog:Array = []
var is_open:bool = false
var is_dialog:bool = false
var dialog_type:DialogType = DialogType.NONE
var actual_line:String = ""
var options:Array = []
var option_index:int = 0

func _ready() -> void:
	visible = false
	cursor_next.visible = false
	control.modulate.a = 0


func _process(delta: float) -> void:
	if not is_open:
		return
	
	if label_dialog.visible_ratio < 1:
		#AA
		label_dialog.visible_ratio += delta * 3
	else:
		if Action.press_once("ui_accept"):
			next_dialog()
		
		if dialog_type == DialogType.QUESTION:
			if Action.press_once("ui_down"):
				option_index = option_index + 1 if option_index < options.size()-1 else 0
				set_line(1)
				
			if Action.press_once("ui_up"):
				option_index = option_index - 1 if option_index > 0 else options.size() - 1
				set_line(1)
			
				


func start() -> void:
	open()
	next_dialog()


func next_dialog() -> void:
	if dialog_type == DialogType.QUESTION:
		dialog_type = DialogType.NONE
		question_finished.emit(option_index)
	
	if dialog.size():
		is_dialog = true
		check_dialog(dialog.pop_front())
	else:
		call_deferred("close")


func check_dialog(line:Variant):
	var type = type_string(typeof(line))
	dialog_type = DialogType.NONE
	actual_line = ""
	options = []
	option_index = 0
	
	if type == "String":
		dialog_type = DialogType.TEXT
		actual_line = line
	elif type == "Dictionary" and "text" in line:
		if "var" in line:
			line.text = line.text.format(line.var)
		
		if "options" not in line:
			dialog_type = DialogType.TEXT
			actual_line = line.text
		else:
			dialog_type = DialogType.QUESTION
			actual_line = line.text
			options = line.options
			option_index = 0
	
	set_line()


func set_line(ratio:int = 0):
	if dialog_type == DialogType.QUESTION:
		var text = actual_line + "\n"
		for i in options.size():
			text += "\t▶\t\t" if option_index == i else "\t\t\t"
			text += options[i] + "\n"
		label_dialog.text = text
	else:
		label_dialog.text = actual_line
	
	label_dialog.visible_ratio = ratio
	cursor_next.visible = true if dialog.size() else false


func set_dialog(lines:Variant):
	var type = type_string(typeof(lines))
	if type == "String":
		lines = [lines]
	
	dialog = lines.duplicate()


func open() -> void:
	is_open = true
	visible = true
	get_tree().paused = true
	var tween:Tween = create_tween()
	await tween.tween_property(control, "modulate:a", 1, 0.3).finished


func close() -> void:
	if not get_tree():
		return
	
	await get_tree().create_timer(0.1).timeout
	var tween:Tween = create_tween()
	await tween.tween_property(control, "modulate:a", 0, 0.3).finished
	
	is_open = false
	visible = false
	get_tree().paused = false
	dialog_finished.emit()
	
