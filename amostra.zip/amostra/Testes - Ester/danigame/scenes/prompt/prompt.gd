extends CanvasLayer

signal prompted(text)

@onready var label = %Label
@onready var line_edit = %LineEdit

var text: String = ""

func _ready():
	line_edit.grab_focus()
	pass


func set_title(title:String):
	label.text = title


func _on_line_edit_text_submitted(new_text):
	text = new_text
	prompted.emit(text)
	queue_free()
