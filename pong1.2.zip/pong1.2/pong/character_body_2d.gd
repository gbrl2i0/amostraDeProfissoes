extends CharacterBody2D
var speed = 35
var dir = 0
@export var num=0
@export var mov = "wasd"
var move={"wasd"=["w","s","p1"],"setas"=["cima","baixo","p2"]}
func _process(delta: float) -> void:
	dir = Input.get_axis(move[mov][0],move[mov][1])
	velocity.y=speed*dir
	move_and_slide()
