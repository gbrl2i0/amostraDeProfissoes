extends State
@onready var footsteps: AudioStreamPlayer2D = $"../../footsteps"
var timer = 0.1
func enter():
	timer = 0.1
	pass
func update(_delta):
	father._handleGravity(_delta)
	father._handlePush()
	var weight = father.selectedPO.weight
	timer-=_delta
	if timer<=0:
		father._handleJumpWeighted(1.2, weight)
		timer = 0.1
		statemachine.change_state("pushAirborne")
		
	pass

func exit():
	pass
