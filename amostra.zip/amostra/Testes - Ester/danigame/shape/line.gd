extends DisplayObject

class_name Line

var from: Vector2
var to: Vector2
var _color: Color
var stroke: float
var antialiased: bool

func _init(x1:float, y1:float, x2:float, y2:float, pcolor:Color, pstroke:float, pantialiased:bool):
	#from = Vector2(x1, y1)
	#to = Vector2(x2, y2)
	from = Vector2(0, 0)
	to = Vector2(x2-x1, y2-y1)
	_color = pcolor
	stroke = pstroke
	antialiased = pantialiased
	x = x1
	y = y1

func get_width():
	return abs(to.x - from.x)
	
func get_height():
	return abs(to.y - from.y)

func _draw():
	draw_line(from, to, _color, stroke, antialiased)
