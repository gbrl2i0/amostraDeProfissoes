extends State
var weight = 0
func enter():
	father._apagarAclamacion()
	weight = father.selectedPO.weight
	pass

func update(_delta):
	#father._handleMovement(0.02,0.04,1)
	#father._handleMovement(1,0.04,0)
	if !father.inBelt:
		father._handleMovement(0.02,0.04,1)
		father._handleSpriteDir()
	else:
		father._handleMovement(0.6*_delta,0.002,1)
	if father.velocity.y>0:
		father._handleJump()
	
	father._handleGravity(_delta,1.05)
	if !father._handlePush():
		statemachine.change_state("walk")
	if father.velocity.y >= -50:
		father._tween("scale",Vector2(1.1,0.9),0.1)
	if father.is_on_floor():
		statemachine.change_state("pushWalk")

	if father._handleDrop():
		statemachine.change_state("walk")
	if father._handleLaunch():
		statemachine.change_state("walk")
		pass
	#father._handleGravity(_delta)
	pass

func exit():
	father.resetMonitoring()
	pass
